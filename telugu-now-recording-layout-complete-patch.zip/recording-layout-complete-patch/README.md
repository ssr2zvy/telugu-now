# Recording, layout and highlight repair

Base: ssr2zvy/telugu-now, grammar, b96a54a87ef195a5b2be9abb364d9c5875d28f9b.

This cumulative patch includes the missing audio-highlight-refinement implementation.
This updated ZIP supersedes the earlier recording-layout-complete ZIP. Apply this cumulative patch once to the base. Do not apply that older ZIP separately. The reader-navigation-repair and settings-navigation-cleanup changes already in this base are preserved.

## Apply

From the repository root, with your changes saved:

```sh
git apply --check /path/to/recording-layout-complete-patch/changes.patch
git apply /path/to/recording-layout-complete-patch/changes.patch
cd upa
npm run build
```

Alternatively copy changed-files into the repository root. Use one method only.
Deploy frontend and backend together. FFmpeg remains required (already configured by the application).
No database migration, volume deletion or progress reset. Nothing pushed or deployed.

## Included

- Word images: swipe left/up or scroll forward for next; swipe right/down or scroll backward for previous. Arrow keys work on desktop. Double-click navigation is removed. Gallery scrolling and action-button taps remain available. A continuous wheel gesture advances at most once.
- Loading dots fade smoothly at their moving edges. Image content and controls are not rendered during image loading, generation or search; no translucent overlay leaves icons visible behind the dots.
- Image prompts accept optional <sentence>, substituted with the current observation transcript. <core word> remains required. Existing prompts and shared word-image galleries are retained. Example: Drawing of <core word> as used in <sentence>. No text in the image.
- Sentence context travels in the generation request body. Identical requests coalesce; distinct sentence prompts do not share an in-flight generation or failed-save retry. Missing required sentence context is rejected clearly. This affects new generations; it does not regenerate saved images automatically.

- Restore Near, Soft, Balanced and Defined highlight presets calculated near the current font color using background colors. Saved preset identity recalculates with appearance changes; explicit custom colors remain supported.
- Place Enabled, Gradient end color and Gradient barrier within Highlight mods as separate pages.
- Audio-bar position anchors the actual single timeline row, including mobile. Magnifier gap controls magnifier distance from that row without repositioning the bar.
- Increase record icon and button size. Add Appearance > Audio controls > Position > Record / switch position (0–200px upward).
- Keep record and switch at a stable shared anchor instead of repositioning them after animated geometry measurements. Begin phase entrance before paint instead of replaying it after readiness.
- Animate audio-bar reveal and associated icon entrance. Reduced-motion preferences remain respected.
- Separate horizontal transcript movement from vertical placement. Outgoing clones no longer apply vertical displacement twice. Fit transcripts with their last line above the audio bar; avoid refitting on unrelated font-load events.
- Remove non-error recording/preparation and playback status text. Keep errors. Reveal and reuse the existing recording timeline and gradient progress when recording starts.
- Fix valid finalized MP4 decoding by giving FFmpeg a seekable private temporary file instead of a pipe. Remove temporary files afterward; keep size, duration, concurrency and processing-time limits and normalized WAV storage.
- Collect recording chunks periodically; report server save errors; retain retryable failed uploads in memory so tapping Record retries saving. Invalid captures can be recorded again. Keep navigation waiting for save completion.

## Investigation and validation

At the base commit, all 26 reader-navigation-repair replacement files and all 5 settings-navigation-cleanup replacement files matched. The missing audio-highlight-refinement files did not match; its helper and tests were absent. The previous claim that this middle patch was skipped was correct for this base.

Reproduced decoder failure using a valid finalized AAC MP4 with trailing metadata. The same recording succeeds with the seekable-input fix. Regression test verifies complete duration and WAV output.

74 focused tests passed (recording, appearance, presets, settings pages, gestures, gradient travel, reader refinements, word images and image prompts). Production frontend/backend build and TypeScript checks passed. Patch checked against a clean index at the base commit; every applied file matches the supplied replacement and manifest hash. Logs included.

Physical iPhone recording and browser visual verification remain outstanding. The reproduced MP4 failure is fixed; this does not establish that every device-specific recording failure has the same cause. Retry audio is held in memory only and is lost on reload. Record/switch placement is deliberately fixed and user-adjustable; extreme offset combinations may overlap controls.
