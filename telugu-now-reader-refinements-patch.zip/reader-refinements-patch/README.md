# Reader and appearance refinements

Patch for the grammar branch of ssr2zvy/telugu-now, based on `bd9c32817f82004184ce9140e2365805c83f297a`.
This base already includes the next-chain settings, Appearance pages and duration-track patches. Apply this ZIP after those changes. Do not reapply the older duration-track ZIP afterward, because that would restore its stronger opacity.

## Apply

From the repository root on grammar:

```sh
git apply --check /path/to/reader-refinements-patch/changes.patch
git apply /path/to/reader-refinements-patch/changes.patch
cd upa
npm run build
```

Deploy the rebuilt frontend and backend together. The backend preference parser must understand gradientBarrier. There is no database rebuild, parser reset or volume cleanup. Nothing was pushed or deployed.

Use either changes.patch or the supplied changed-files replacements, not both. The patch is recommended; every applied file has been checked against its packaged replacement.

## Included changes

1. Random colors are generated from continuous random hues, spread, saturation and lightness. Related background stops and contrasting tinted text are calculated each time. The generator checks text contrast against each stop and avoids black/white text extremes. Named color presets remain intentional preset choices; Randomize no longer picks from five hardcoded palettes.
2. Text-given questions and comparisons use the normal observation audio-bar anchor, respecting existing audio offset and magnifier orientation. Record and evaluation retain one shared action slot near the safe bottom edge. Their position is independent of the audio bar. Actual scrubber/magnifier/timestamp/speed-control bounds are measured; when they overlap that slot, the action moves above the obstruction. The bar is not moved to accommodate it. With a magnifier above the bar, the action may therefore sit above the audio controls. Text, recording behavior, evaluation commits, progress and seek logic are unchanged.
3. Settings icon fades after three seconds without pointer, click, wheel, keyboard or focus interaction. Holding a pointer keeps it visible until release. Only SVG opacity changes: the 44px button remains clickable when invisible. Interaction reveals it; keyboard focus keeps a visible icon.
4. Reader dots wait 250ms and are only eligible while the reader is blank. Text-given text readiness suppresses them even if audio/prewarming is still finishing. They are removed immediately without fading out when content appears. A single reader loader replaces overlapping loading paths. Preparing the next question no longer puts dots over the displayed observation. Letter-detail dots also get the delay. Playback/navigation readiness checks remain in place.
5. Appearance > Letter modifications > Gradient barrier replaces the Modification lightness page. Range 0–100, default 50. Lower values spread the color blend; higher values sharpen it. Default 50 exactly preserves the previous transition curve. Observations, comparisons, word/letter views and neighboring prewarm/cache keys all use it. The old lightness field remains internally for compatibility with saved Text shift color presets, but has no settings control.
6. Removed the comparison switch's focus/click border. Keyboard focus emphasizes its indicator instead. The false/true draft, default false, saved-answer locking and forward-navigation commit behavior are unchanged.
7. The duration line opacity is reduced from 28% to 14%. Its 1px geometry and palette-derived color remain; progress/cursor/playback logic is unchanged.

## Validation

38 focused checks passed: generated palettes, contrast, settings navigation, gradient curves and cache keys, preference compatibility, loading conditions, action placement, material controls and swipes over controls. Includes 1,000 generated palettes and action-placement calculations for short/mobile screens with different safe-area/row dimensions.

Production build passed (TypeScript, frontend, backend and worker assets). Patch whitespace and clean-index application checks passed. Logs are in validation/.

Physical iPhone interactions and browser visual rendering were not verified in this environment. Layout tests cover positioning calculations, not screenshots. Unrelated legacy test suites were not run.
