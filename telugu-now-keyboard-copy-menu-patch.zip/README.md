# Keyboard Copy menu patch

Base: ssr2zvy/telugu-now main at 22010e25f7fa99e20bd725fa730e804521f53d6e.

Long press (500 ms) in either the free-typing keyboard or the audio-given question keyboard opens the existing menu with only its Copy icon. Copy uses the entire current draft and preserves free-typing line breaks. Holding a keyboard key does not type that key on release.

The typing area suppresses native touch selection, cursor placement, browser context menus and double-click selection. A short tap focuses the existing insertion point; virtual typing and hardware keyboard editing remain available. Vertical dragging scrolls long drafts. Keyboard gestures no longer navigate observations. Existing observation/word/letter menus retain both Copy and Free typing.

The menu is mounted outside the question keyboard's clipped/transformed container, and inside the free-typing dialog when that dialog is open.

## Apply
Choose ONE method, from the repository root:

1. Apply changes.patch:
   git apply --check /path/to/changes.patch
   git apply /path/to/changes.patch

2. Or copy the contents of replacement-files/ over the repository, preserving paths.

Do not apply both methods. New source files are included. No dependencies, deployment settings, credentials, parser code or volume data are changed. This ZIP has not been pushed or deployed.

## Validation
- TypeScript typecheck passed.
- Production client build passed.
- 12 reading-menu/render and reader-tap tests passed.
- DOM interaction checks passed for both real keyboard contexts: whole-draft copying, modal-safe menu placement, native event cancellation, held-key release, drag scrolling without reader navigation, outside dismissal without typing, and subsequent ordinary key taps.
- Patch applied to a clean temporary index at the base commit; every resulting file matched the replacement files.

Physical iPhone/iPad Safari was not available for testing. After deployment verify: hold the typed text and a virtual key, copy the draft, scroll a long draft, dismiss the menu, then type normally. No browser selection handles or clipboard callout should appear from touch gestures.
