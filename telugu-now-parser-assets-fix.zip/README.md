# Grammar parser asset packaging fix

Base: ssr2zvy/telugu-now grammar, c526da9a2a6d53940bb8346b24680eaad7613a08.

## Failure

The status response reports a missing deployed file:
 /app/upa/dist/server/parse-core/parser/data/lexicon.json

This is an asset-loading failure before observation processing. The worker reaches
loading-parser after fingerprinting. HTTP 200 on the polling endpoint only means
the status response was delivered; it does not mean the background parse succeeded.

The branch's .dockerignore omits parse-core from its default-deny allowlist and
also excludes directories named data. The exact image used for the failed
deployment was not available to inspect.

## Changes

- Include parse-core in the Docker context and explicitly restore its three
  versioned dictionary JSON files after the generic data exclusion.
- Validate all six runtime JSON assets before and after packaging; missing or
  malformed files now fail the application build. Clear only generated parser
  output before copying, so stale output cannot hide incomplete source assets.
- Initialize CoreParser(build_index=False) in the final image during its build.
  This checks the deployed module path and dictionary loading without constructing
  the expensive surface index or reading the user's corpus.
- Log parsing_job_failed with the job ID, error, prior phase and counts. Previously,
  the worker saved errors to status without emitting a server error log.
- Add dependency-free packaging regression tests.

## Apply

From the grammar repository root, using the extracted changes.patch:

    git apply --check /path/to/changes.patch
    git apply /path/to/changes.patch
    node --test upa/scripts/package-grammar-worker.test.mjs

The files/ directory contains the same five changed files as a fallback.
Use the patch or the replacement files, not both.

Rebuild and redeploy the image through the usual deployment process. Restarting
the old image alone cannot restore missing files. Then retry corpus parsing.

The previous failure may have committed an empty checkpoint using a fingerprint
that excludes the missing assets. Restoring assets changes that fingerprint.
If the first retry reports STALE_INPUT, retry again: the existing worker then
starts a fresh build. No corpus or learner progress deletion is required.

## Validation performed

- Nine packaging tests passed: copying real paths, excluding Python caches,
  removing stale generated output, six individual missing-asset cases, and
  malformed JSON.
- All 21 local parser source files matched the base commit's Git blob hashes.
- Packaged the actual parser source assets and initialized the packaged parser:
  1,127 lexemes and 126 modifiers loaded successfully.
  The unrelated build-grammar source directory was an empty fixture for this check.
- Worker TypeScript syntax checked with Node's TypeScript transformer.
- Patch checked and applied against exact base file contents.
- No full application build, Docker image build, or 331,768-observation production
  parse was run in this environment. The new image-build smoke check still needs
  to pass during deployment.

