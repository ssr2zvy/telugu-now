# Validation performed

The included focused integration fixture passed on Node 24.19.0:

```sh
cd upa
node --experimental-vm-modules tests/parsing-diagnostics.fixture.mjs
```

It executes the actual changed `state`, `catalog`, `queue-service`, `audit`, and
`diagnostics` modules against real SQLite databases. It adapts the synchronous
better-sqlite3 calls to Node's built-in SQLite and stubs unrelated source, legacy
GI, audio-identity, logging, and question-presentation services. It does not claim
to run the production Node dependency stack.

Covered behaviors:

- Full-inventory mastery denominator, split vocabulary/chain percentages, and
  zero-example target retention.
- Duplicate corpus rows versus distinct normalized sentence counts.
- Pending answers do not alter mastery before the entire batch is answered.
- Answer/display retries do not duplicate diagnostic credit; batch application
  remains idempotent.
- False resets, including an already mastered neighbor; ordered before/after
  streak evidence.
- Full-batch restart, early neighbor exhaustion, blocked random starts, and
  non-spamming persistence of blocked-selection evidence.
- Selected sentence, predecessor, candidate availability, and parser snapshot
  are retained with observations.
- Preparation-ready events; replacement and pre-deletion evidence; unavailable
  media/text suffix truncation with its supplied rejection reason and no False
  credit.
- Failed database transactions roll back their audit writes.
- Profile isolation; all-core streaming export; nested saved snapshots; history
  pagination; persistence after reopening SQLite; restart-safe initialization.
- A dedicated export read snapshot excludes events written after it was opened;
  early termination releases the export reader.
- Core advancement still requires every target; stale corpus counts are null,
  not fabricated zeros.

Also completed: TypeScript syntax transformation for changed backend/shared
modules, TSX syntax parsing for both page components, whitespace checks, and
clean patch application to the captured predecessor files with output-hash
comparison.

Not run: full application type checking, the full npm test suite, production
better-sqlite3 integration, authenticated HTTP endpoint integration, a rendered
browser UI test, million-row performance benchmarking, or deployment. The
workspace did not contain the app's npm dependencies. Run the normal application
gates listed in README before deploying. The included dependency-free fixture
requires Node 24+; runtime application changes retain the existing Node 20+
requirement.
