# Implementation map

| File | Purpose |
| --- | --- |
| `upa/server/src/parsing/audit.ts` | Additive audit tables, indexes, preparation/deletion triggers, restart-safe retained-history baseline, event writer. |
| `upa/server/src/parsing/state.ts` | Mode, first-display, answer, ordered progress-application and core-advancement event hooks. |
| `upa/server/src/parsing/catalog.ts` | Attach candidate considered/available IDs to the existing random/neighbor choices and terminal decision, without changing selection probabilities. |
| `upa/server/src/services/queue-service.ts` | Record path starts/endings, blocked seeds, exact selected evidence, replacement links and discarded suffixes. |
| `upa/server/src/services/preparation-service.ts` | Pass the existing rejection code into the replacement audit. |
| `upa/server/src/parsing/diagnostics.ts` | Cached corpus aggregates, profile progress and appearance metrics, paginated events, consistent streaming JSON export. |
| `upa/server/src/parsing/routes.ts` | Add profile-scoped diagnostics, event, and export GET routes using the existing profile validation middleware and no-store response caching. |
| `upa/shared/parsing-diagnostics.ts` | Server/UI diagnostic data contract. |
| `upa/frontend/src/settings/pages/ParsingDiagnostics.tsx` | Percentages, core/ranking controls, expandable least-30 tables, event history, export link. |
| `upa/frontend/src/settings/pages/ParsingPage.tsx` | Mount the diagnostics inside the existing Parsing mode tab. |
| `upa/tests/parsing-diagnostics.fixture.mjs` | Focused real-SQLite integration fixture with no npm dependencies. |

## HTTP additions

All routes use the existing `/api/profiles/:code/parsing` prefix and profile-code
validation. They do not call the parsing worker or change selection mode.

| Method / suffix | Result |
| --- | --- |
| `GET /diagnostics` | Current all-core metrics and target rows for this profile. |
| `GET /diagnostics/events?core=1&before=<seq>` | Up to 50 descending events for the chosen core plus profile-level events; `nextBefore` continues without offset drift. Core must be 1–3, cursor a positive safe integer. |
| `GET /diagnostics/export` | Download complete retained profile Core diagnostics as streaming JSON. |

The export is not capped to the page's selected core, event page, or least-30
slice. No new operator token is needed for a profile's read-only diagnostics.
The original global parse-build endpoint keeps its existing operator gate.
