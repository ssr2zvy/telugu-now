# Telugu-now — Core diagnostics companion patch

Apply **after** `telugu-now-grammar-parsing-patch.zip` from the `grammar` branch.
This ZIP contains implementation source, a unified patch, and a focused SQLite
fixture. It is not merely a requirements document and has not been deployed.

## Apply in order

1. Apply the original parsing patch. Its stated base is
   `65fc6ec8aaba44ade73760eb59f35614a4584979` in `ssr2zvy/telugu-now`.
   Commit `273eccf7519f07ea8b8f01b863db2985d3d4d319` uploaded that ZIP; uploading
   the ZIP did not apply its contents.
2. Extract this companion ZIP outside the repository. From the repository root:

   ```sh
   git apply --check /absolute/path/to/telugu-now-core-diagnostics-addon/changes.patch
   git apply /absolute/path/to/telugu-now-core-diagnostics-addon/changes.patch
   cd upa
   npm ci
   npm run typecheck
   npm test
   npm run build
   ```

3. Deploy through the app's existing process. On startup the add-on creates two
   small additive tables, indexes, and audit triggers in the existing user
   database. Retained earlier Core observations receive an explicitly labeled
   baseline snapshot.
4. Open Settings → Parsing mode → **Core diagnostics**.

`files/` contains the complete added or changed files at repository-relative
paths. Apply the patch OR copy these files, not both. `manifest.json` includes
input/output SHA-256 hashes. Later changes to these same files need a reviewed
merge rather than overwriting newer work.

No Python parser, graph, matching rule, inventory, corpus database, or progression
rule is changed. Existing completed parsing snapshots remain compatible; this
add-on alone does not require a reparse. It adds no npm dependency.

## What appears on the page

- Core 1, 2, and 3 each show a prominent percentage, progress bar, mastered/total,
  remaining count, and current/completed/upcoming state.
- Vocabulary and modifier-chain percentages appear separately under each core.
- Example coverage and targets with zero examples remain separate from mastery.
- Answers already recorded but awaiting the rest of their batch are shown as
  pending; they do not inflate the applied mastery percentage.
- A core selector and two expandable tables show the 30 least-appearing
  vocabulary targets and complete modifier-chain targets for that core.
- A ranking selector switches between distinct corpus sentences and observations
  first displayed to the current profile. Zero-count targets appear first.
- An expandable, paginated movement/observation history shows random starts,
  path endings, replacements, discarded reservations, preparation changes,
  first displays, answers, applied streak changes, and core advancement.
- **Export all Core progress and movement history (JSON)** downloads the complete
  retained history for this profile across all cores, not only the displayed
  table or its 30 rows.

The two kinds of “chain” are deliberately labeled: a **modifier chain** is a
complete grammatical target; a **movement chain** is the sequence of selected
targets within a batch. Ending a movement chain does not reset mastery streaks.

## Completion remains exactly the original rule

For each target, True raises the consecutive-True streak by one, capped at 3;
False sets it to 0. A target is currently mastered at streak 3. A mastered target
that appears later as a neighbor can be reset by False, as in the original ZIP.
Updates apply in original slot order only after the entire retained batch has
answers. Every required target in the current core must be mastered before
advancing. Missing examples do not remove requirements or count as success.

The displayed completion formula is:

`100 × currently mastered required targets / all required targets in the core`

It is **not** the percentage of questions answered, corpus rows parsed, available
targets mastered, or partial streak credit. A target with a 2/3 streak contributes
zero mastered targets. A zero-sized inventory shows unavailable rather than
inventing 100%. Inventory mismatches are surfaced, with percentages hidden in the
page; raw saved progress remains exportable.

## Frequency definitions

| Column / ranking | Meaning |
| --- | --- |
| Corpus sentences (default ranking) | Distinct Unicode/whitespace-normalized sentence hashes with an accepted match to this exact target. Duplicate source rows sharing that sentence count once. |
| Source rows | Distinct parsed source rows containing the target, using the existing deduplicated `members` table. |
| Audio references | Those source rows with a nonempty audio key. This does not claim the audio is playable, unblocked, or unused. |
| Selected | Distinct reservation/observation IDs, including subsequently replaced or discarded reservations retained in the audit. |
| Displayed to me (alternate ranking) | Distinct observation IDs first displayed for that selected target. Reopening the same observation does not increase this count. |
| Answered | Distinct selected observations with an explicit True/False result, including pending batch results. |
| True streak | Current applied consecutive-True streak; mastery is at 3. |

The vocabulary and chain tables use **all** required targets, including zeros,
filter by core and kind, sort ascending by the chosen frequency, then by stable
target ID, and take up to 30. There is no arbitrary source-order tie break.

Modifier rows use the existing graph's selectable `kind: chain` targets. A single
modifier is a one-component chain; longer ordered chains and combined alternative
targets keep their existing identities. Components inside a longer chain are not
silently treated as separately mastered or separately matched targets. The table
shows ordered components/alternatives and the stable ID.

Corpus numbers are parser-confirmed matches from the completed snapshot, not
substring guesses. If the snapshot is stale/unavailable, corpus counts show
unavailable, not zero. The first diagnostic read aggregates the existing index;
subsequent reads cache those corpus aggregates per immutable snapshot. Profile
progress refreshes every five seconds while the page is open. Event history is
loaded when expanded, with explicit refresh and older-page controls.

## Movement and observation evidence

A random start records the new batch, its core/inventory, prior batch/core,
whether this is a restart, and why a new path started. Each selection records:

- Observation ID, batch ID, zero-based slot, current/from target IDs, and
  seed/neighbor transition.
- Candidate target IDs considered and the IDs with a usable shortest example at
  that decision, when the original batch is drafted.
- Target snapshot, exact sentence text, source ID/key, row ID, normalized text
  hash, accepted length, selected token offsets, parser evidence, question type,
  and catalog identity.

A full batch records `batch-full`. Exhausting eligible neighbors records
`no-unused-neighbor` and the final candidate decision. If no seed has an unused
eligible example, `walk-blocked` records `no-unused-unmastered-target`; unchanged
consecutive polling failures are coalesced. An empty candidate list versus a
nonempty but unavailable list is visible in the decision data. A target's
unavailability is assessed by the existing selector's combined gates (prior use,
reservations, blacklist, audio availability/validation); the add-on does not
invent a per-gate cause that the selector did not return.

Rejected media/text reservations preserve their pre-deletion snapshot. A
same-target replacement links the old and new observation IDs and records the
upstream rejection reason (for example `blacklisted-text` or an audio validation
code). If no replacement is possible, `walk-truncated` records
`unavailable-media-neighbor`, the rejection reason, and every discarded suffix
observation. The next random start links back to that batch. Truncation itself
never creates False answers or mastery credit.

`walk-closed` marks the end of drafting a path, not its display or completion.
`batch-applied` marks answer application. A queued reservation is never labeled
as displayed. Preparation triggers record ready/failure/retry transitions in the
same database operation as the observation update. Display and answer retries
are idempotent. `progress-applied` records each result's before/after streak and
mastery state in actual application order. These events remain after reservations
are deleted because observation IDs in the event table have no cascading FK.
Profile deletion still cascades the profile's diagnostic events.

## Historical boundary

Exact events start when this add-on is installed. Earlier retained observations
are exported as `legacy-observation` with `reconstructed: true` and their actual
saved state. The add-on cannot recover reservations already deleted before
installation, intermediate streak changes, or old reset reasons that were never
saved. The page and export disclose this limit. It does not fabricate historical
walks, displays, or perfect coverage. Audit initialization is restart-safe.

## Export

The download is UTF-8 JSON with format `telugu-core-diagnostics`, version 1.
It contains:

- `summary`: all target metrics and all three core summaries, inventory ID,
  timestamps, missing/stale catalog warnings, and historical limits;
- `inventory`: the complete bundled target definitions and movement graph;
- `progress`, `streaks`: saved progress including all retained inventory IDs;
- `batches`: frozen starting snapshots, sizes, application states, end reasons;
- `observations`: retained Core selections, source coordinates, current text and
  preparation state, timestamps, answers, question type, and parser snapshots;
- `usedSentences`: the per-core sentence-reuse tracking records;
- `activeQueue`, `parkedQueues`: queue positions and IDs (other parked modes may
  be listed for context but their learning results are not counted as Core work);
- `events`: the entire ordered event journal, including discarded observations;
- `eventHighWater`: the last included event sequence for the selected profile.

Saved JSON columns are decoded into nested objects. Event sequence numbers are
monotonic database IDs; gaps in one profile's export are expected because other
profiles also use the table. Slots are zero-based in data, one-based on the page.
Timestamps are Unix milliseconds.

The export uses a separate read-only SQLite transaction and streams records with
backpressure rather than building the whole observation/event history in RAM.
Client cancellation closes the reader. It excludes credentials, operator tokens,
raw audio, and recorded answer blobs. It is a diagnostic export, not a restore
archive. Corpus/parser provenance is included in selection events. Normal app
backup policy is still responsible for retaining the user database; diagnostics
do not introduce a separate Tigris upload.

## Validation

See `VALIDATION.md` for checks actually run and limits. No live corpus, deployment,
or browser end-to-end test was performed for this ZIP.
