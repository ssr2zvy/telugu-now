# Consolidated diagnostics and shorter Core 1 observations

Base: `ssr2zvy/telugu-now`, `grammar`, commit `29bc8f8d71b39c9fae097813498c8ac2dd8cefde`.
This is a follow-up to the live frequency parsing patch already merged into this branch.

## Apply

From the repository root, with this ZIP extracted elsewhere:

```sh
git apply --check /path/to/consolidated-diagnostics.patch
git apply /path/to/consolidated-diagnostics.patch
cd upa
npm run build
npm run test:live
```

`changed-files/` contains the complete replacement/new files with repository-relative paths. Use either the patch or those files. The patch was checked against the exact base commit, and its applied contents were verified byte-for-byte. `manifest.json` records SHA-256 hashes.

## Behavior

- One top-level **Observations & diagnostics** section consolidates the former parsing and observation sections. Its main page shows the current matched word highlighted in its sentence, the selected object, its modifier chain where applicable, and the connection cycle containing the current observation. Queued, current, shown and answered steps are distinguished.
- Core 1 coverage is the default. Objects are sorted by distinct cached matching words, least represented first. Zero cached matches and never shown are separate states. Other cores can also be inspected.
- Question type is a child settings page and remains the only sampling control. Every selection remains a question.
- A dedicated **Download full diagnostics** page exports all recorded observations, acquisitions, selections, searches, connection cycles, responses, presentation history, progress, events, pending queue and Core inventory for the profile. It has no date or row limit. Earlier observation records without a live-selection row are included. Existing legacy grammar selection/progression records are included when present; this does not enable another selection mode. Audio binaries are excluded, with response audio metadata retained. The JSON export schema is version 2.
- The shortest matching usable word takes priority over longer words, whether cached or not. Word length uses Unicode code points. At equal length, unchecked words are tried before cached matches; remaining ties use word order. Parsing remains bounded to 16 candidates per worker request, with no context checking.
- **Core 1 observations:** find distinct usable observations containing that word, order by the corpus `grapheme_count`, retain the first five, and choose uniformly at random from that pool. If fewer than five exist, use all available ones. Equal-length boundary ties use source ID and source key. Blacklisted sentences, missing availability/audio references and known-invalid audio are excluded before forming the pool. Media is still validated during preparation; a newly discovered bad recording is quarantined and replaced by the existing flow.
- **Core 2 and Core 3 observations:** retain random selection across all usable matching observations.
- Multiple occurrences of a word in one observation do not add probability. No previous-use exclusions are introduced. Existing Core progress, completed-object exclusions and chain rules are preserved.
- Parser loading, word searching, audio preparation and ready questions are shown separately. Recorded word evidence is distinct from whole-cache counts: other words in the current sentence are not marked as failed.

## Existing data and deployment

This package contains source changes only and has not been deployed. Build and deploy the frontend and backend together using the existing branch workflow.

Currently displayed and already queued questions keep their saved selection. New selection rules apply when new questions are selected. Older records that lack exact word/chain evidence are labeled explicitly; no word is guessed from a target name.

The existing worker fingerprint includes its Python source. This update therefore invalidates saved word parse results once at first startup; words are reparsed on demand. It does not reset user progress or erase observation/chain history, and it does not require a full grammar-database build. Coverage counts describe the current parse cache; shown counts and cycle history remain cumulative.

No corpus database is deleted, no new frequency-cache columns are added, and no per-occurrence parsing table is introduced. Core 1's shortest-five lookup joins the existing occurrence references to the corpus and availability databases. Production-scale latency has not been measured on the user's full volume.

## Validation

- `npm run build`: production frontend, backend and packaged parser build passed.
- `npm run typecheck`: passed after final changes.
- `npm run test:live`: 29 focused tests passed (16 Python and 13 Node tests).
- Coverage includes shortest-word priority across cached/new parses, bounded search, five-shortest observation selection, exclusions before pooling, occurrence deduplication, matched-word rendering, Unicode span validation, consolidated navigation, readiness states, Core progression, cycles and all-history export. The final export integration check also verifies an older observation without a live-selection row.
- Patch application and exact reconstructed file contents verified against the base above.
