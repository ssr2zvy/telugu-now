# Text-given comparison and swipe patch

Base: grammar branch, commit c752e4e572d671b41f4e06545e75199093902832. Apply on top of the iPhone/comparison-controls changes already merged at this commit.

From the repository root:

```sh
git apply --check /path/to/changes.patch
git apply /path/to/changes.patch
cd upa
npm run build
node --import tsx --test tests/text-comparison.test.ts tests/recording-audio.test.ts
```

Alternatively, copy the files in changed-files/ over the matching repository paths. Use one method, not both. The ZIP contains source changes, tests, and this guide; no database edits or deployment.

## Behavior

Text-given questions retain their prompt in the same layout during comparison. The recording player leaves and the correct-audio player enters; only one player is rendered. Comparison always initially reveals the correct-audio bar, without autoplay. The unlabeled switch occupies the record button position beneath the full audio/magnifier footprint, with bottom safe-area clearance. Its 76 x 48 px touch target contains a compact track and movable gradient thumb.

Swipe left / Right Arrow advances. Swipe right / Left Arrow returns. Swipe down / Down Arrow reveals the bar, then opens its associated controls; repeated down leaves those controls open. Swipe up / Up Arrow collapses associated controls, then hides the bar. Controls own their drags and keyboard editing. Gestures are scoped to the text-given question/comparison/observation sequence. Audio-given comparisons, word/letter inspection, gallery and bookmark-loop gestures are unchanged. The broader all-app double-click removal and click ripple are outside this small patch.

Forward from comparison submits the switch once. Default is off. A draft survives going back before submission; a submitted answer is disabled on return and cannot change progression. Recording presence never sets the switch. Navigating away waits for an active recording to stop and upload; failed saves keep the question open. Returning to the question reveals the saved recording. The final phase remains the normal observation layout.

Only the controls animate horizontally; text stays fixed. Reduced-motion preferences suppress animation. Existing typography, waveform sizes, colors and audio processing are retained.

## Validation

Production build and TypeScript check passed. Focused tests cover direction/threshold/diagonal rejection, prompt visibility across phases, default/draft/final switch rendering, and MP4/WebM/WAV conversion. Broader live-parser test initially timed out while waiting for the worker; see validation.txt for final results. Browser installation failed with truncated downloads, so real browser animation and iPhone touch behavior are not verified.

## Device acceptance checks

1. Open a text-given question. Down reveals the record control; repeated down never hides it. Record and stop. Swipe left, including while a recording is finishing its upload.
2. Verify the text does not move, only correct audio appears, and the switch replaces the record button with no visible label or divider. Repeat after hiding or expanding the recording bar before leaving.
3. Toggle the switch in both directions with a recording present. Go back before submission; replay the recording and return. The draft remains.
4. Advance from comparison with off, then separately with on. Return to each answered comparison: the saved switch is locked and progression does not change.
5. Verify correct-audio controls open on every comparison entry, then down/up reveal and collapse directionally. Dragging a scrubber must never change pages.
6. Repeat with desktop arrows, keyboard focus inside a scrubber, narrow iPhone viewport, magnifier above/below, and reduced motion. Final observation has the normal layout.
