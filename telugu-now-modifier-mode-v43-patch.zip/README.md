# Telugu-now: Modifier mode v43 patch

Base: main at 7e9c589bc3ced002bffa56ae2894458e456948e6.

Includes all 158 grammar entries / 283 examples from the supplied v43 archive,
the triangle / ? navigation control, persistent per-profile switches, random
selection and history, remaining count, settings lists and reset.

## Apply

Use ONE of these methods:

1. Copy the contents of `files/` into the repository root, preserving the `upa/`
   directory structure and replacing the matching files.
2. From the repository root, run `git apply --check /path/to/modifier-v43.patch`,
   then `git apply /path/to/modifier-v43.patch`.

The replacement files and unified patch are equivalent. Do not apply both.
On a newer branch, prefer git apply so conflicts are reported rather than
silently replacing intervening work.

Build/deploy main through your existing process. The profile database table
is created automatically; no secrets, manual data imports, or Fly changes.
This ZIP has not been pushed, merged or deployed.

## Validation

Production build and all six focused tests passed. React DOM interaction
checks passed. The complete test suite had the same 81 existing failures as
the untouched base (409 passed here vs 403 at base). Actual iPhone/WebKit
visual testing was unavailable. Full behavior and validation notes are in
`files/upa/docs/modifier-mode.md`.

The patch was applied to a separate checkout of the base and every resulting
file was byte-compared with the replacement files.
