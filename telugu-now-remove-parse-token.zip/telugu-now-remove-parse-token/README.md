# Remove the Parse entire corpus operator-token gate

Base: ssr2zvy/telugu-now, grammar, ba964b0dbb4d9ca5bfad7741533f5f22ca8f2ff7.

This patch removes the token prompt, the token header, and the server token
requirement for the current Parsing mode build/resume endpoint. Existing valid
profile checks, cross-origin mutation checks, and the worker's single-job lock
remain in place. The parsing page no longer requires GRAMMAR_MIGRATION_TOKEN to
be configured. Corpus parsing, Core progression and diagnostics are unchanged.
The old retired GI migration feature is not rewritten.

## Apply

From the repository root on the grammar branch:

```sh
git apply --check /absolute/path/to/telugu-now-remove-parse-token/changes.patch
git apply /absolute/path/to/telugu-now-remove-parse-token/changes.patch
cd upa
npm ci
npm run typecheck
npm test
npm run build
```

Deploy through the existing workflow. No parsing database rebuild or progress
reset is required. Complete replacement files are in files/; use the patch OR
copy these files. The original parsing and diagnostics patches are already in
the base commit and are not bundled again.

## Positioning request — still unresolved

This ZIP makes NO changes to control sizing, CSS breakpoints, recording-button
positioning, or audio-bar positioning. The proposed sizing/breakpoint changes
were discarded after the user's correction.

The source comparison used:
- main: 340c141b421a4649ca573ec486e8f1fe214fa697
- grammar: ba964b0dbb4d9ca5bfad7741533f5f22ca8f2ff7

Both checked-in branches already contain the same relevant positional rules:
- appearance.tsx sets audio-placement-bottom to the safe-area bottom plus 16px,
  with a minimum of 16px; it passes the saved audioOffset into the same variable.
- observation-layout.css centers the bar at left:50% with translateX(-50%)
  and anchors it at the same computed audio-bottom.
- The text-given record controls use the same bottom expression: audio-bottom
  + audio-row-height + audio-detail-height + record-gap.
- The existing phone portrait record-gap is clamp(19px, 3.5dvh, 42px) in both.
- Comparison audio bars use the same relative positioning and centered alignment.
- The shared appearance definitions and server preference service are identical.

The source comparison therefore does not identify the reported rendered shift.
A screenshot of main and grammar at the same viewport/question phase is needed
to target that positioning change. Saved appearance values, viewport/safe-area
behavior, and the actual deployed asset version have not been inspected. These
are things to check, not established causes. No arbitrary offset was added.

## Validation

Passed: changed TypeScript/TSX syntax checks, direct handler smoke checks using
stubbed service/router adapters (token absent, obsolete token present, invalid
profile, cross-origin rejection, worker-conflict status), git diff whitespace
checks, clean patch application and output hash checks.

The existing parsing-mode test was updated to exercise token-free build requests
without launching a real worker. A callback defaulting to startParsing supplies
the worker launch seam; production behavior uses the existing worker.

Not run: full npm test/typecheck/build, real HTTP integration, on-device/browser
rendering, or deployment. App dependencies and browser executables were not
available in this workspace. This ZIP is ready for review/apply; it is not a
claim that the live positioning issue has been fixed.
