# Telugu-now: live parsing from frequency words

Patch base: `ssr2zvy/telugu-now`, branch `grammar`, commit
`ef73558065eac31f3b983550be4a5341c7b17190`.

## Apply

From the repository root, with this ZIP extracted elsewhere:

```bash
git apply --check /path/to/live-frequency.patch
git apply /path/to/live-frequency.patch
cd upa
npm ci
npm run test:live
npm run build
```

The `changed-files/` directory contains the exact changed/new source files as an
alternative for manual review or overlay. Use the patch OR the overlay, not both.
Rebuild and redeploy the image after applying. This ZIP does not deploy it.
No full-corpus parse button, checkpoint resume, or manual SQL migration is needed.

## Runtime files and migration

The existing frequency database is required. Default paths under DATA_DIRECTORY:

- `corpus/corpus.sqlite`: unchanged observation text and audio references.
- `corpus/frequency.sqlite`: existing `frequencies`, `occurrences`, `metadata`.
- `corpus/availability.sqlite`: existing audio-presence membership.
- `corpus/audio-validation.sqlite`: existing audio validity/quarantine records.
- `user/users.sqlite`: existing history/progress, plus connection-cycle diagnostics.

`FREQUENCY_DATABASE_PATH` can override the frequency path under DATA_DIRECTORY.
The default works with `/data/corpus/frequency.sqlite`. A missing file is an error;
the worker never creates an empty replacement frequency corpus. It opens the
canonical corpus and availability read-only.

First live worker startup adds one nullable TEXT column,
`frequencies.parse_result`, and a single cache-version column on `metadata`.
It reuses an existing index whose leading column is `occurrences.normalized_word`.
If absent, it creates `live_occurrences_word(normalized_word)`; this can require
significant disk space on 4.1 million occurrences. The occurrence rows and counts
are not copied or rewritten. SQLite WAL files may appear beside frequency.sqlite.
Do not manually delete live SQLite WAL/SHM companions.

Old full-corpus parsing outputs and common-words.sqlite are not read by this
selection path. The patch deliberately does not delete existing files or remove
legacy database columns. In particular, availability's historically named
`source_complexity_members` table is still used for audio presence, not weighting.
Do not delete availability or its tables before replacing that storage contract.
Audio validation remains useful and is preserved.

Old undisplayed queues are retired on first profile use. Displayed history and
compatible Core streaks remain. The graph inventory hash matches the prior
builder exactly, so a parser-cache version change does not reset user mastery.
An actually different target inventory produces a migration error, not a reset.

## Selection behavior

- This branch always runs Core live parsing, always producing questions.
- No weighted, full-random, seen/unseen, or full-corpus-build route is active.
- A random unfinished Core 1 object starts the first cycle. Later cores start
  only when all objects in the previous core have three consecutive Trues.
- Candidate retrieval searches DISTINCT frequency words by per-object Unicode
  fragments and a hard maximum length. Length is Unicode code points, including
  combining signs, not Telugu grapheme clusters.
- Retrieval definitions are derived from the existing parser's registered
  single-word realizations. Vocabulary uses its listed forms; modifier targets
  use terminal Unicode fragments from their registered realizations. Maximum
  length is the largest registered realization for that target. These are
  bounds within the installed registered grammar, not a guarantee about every
  possible Telugu word. The actual fragments/caps are visible and exported.
- Phrase-only objects with no single-word realization stay without matches;
  they are not silently completed, converted to single words, or context parsed.
- Unchecked matching words are tried first, in deterministic word order.
- A resolved word saves all qualifying vocabulary/complete-chain target IDs.
  Ambiguous, incomplete, unresolved, and non-curriculum results save no_parse.
  A successful match to B is retained even if the current search was for A.
- There are no sentence-context checks or context-review overrides.
- Existing occurrence links locate a RANDOM DISTINCT eligible observation for
  the matching word. Multiple occurrences in one sentence do not give it more
  probability. Previously displayed observations remain eligible.
- Only after unchecked candidates are exhausted does selection reuse cached
  matching words, with a random eligible observation. Explicit user blacklists,
  audio presence, and invalid-audio quarantine still apply.
- Subsequent objects follow explicit graph neighbors, excluding completed
  objects and those already selected in the current in-memory cycle.
- No eligible connected target: close the cycle and randomly reseed unfinished
  objects. A failed candidate chunk is not a dead end: the search continues
  through the remaining unchecked candidates and cached alternatives.
- Preparation has a maximum of three queued questions ahead. A target with an
  unanswered reservation waits for that answer before being reserved again;
  temporary waits are not marked corpus exhaustion. This prevents completion
  races while allowing observation reuse across answers/cycles.
- True advances the selected object's streak; False resets it; each answer
  applies immediately. A completed object remains completed. A multi-target
  parse does not give incidental mastery credit to other objects.
- If nothing qualifies, the unfinished core remains blocked with a visible
  diagnostic reason. It retries after 30 seconds; it never skips missing targets
  or falls back to another sampling mode.
- Process restarts start a fresh in-memory chain and retain queued questions,
  cached word results, user progress, and the saved cycle/search history.

## UI and diagnostics

The only sampling setting is question type: audio-given vs text-given probability.
100% always produces audio-given questions; 0% always produces text-given ones.
Already queued questions keep their recorded type. Existing question answer,
comparison, evaluation, audio, appearance, and navigation flows remain in place.
The existing LoadingSlit is used while waiting for a parsed question.

Live diagnostics refresh every three seconds and default to Core 1. They include:

- All objects, sorted by distinct cached matching words, fewest first.
- Current streak/completion, search count, newly checked candidate count,
  exhausted searches, and number of presentations.
- The actual per-object Unicode fragments and maximum code-point length.
- Shared cache totals: unchecked, resolved, and could-not-parse words.
- Current target/search status and explicit worker failures.
- All-cycle totals, selected steps, active cycles, and end/restart reasons.
- Recent events, plus a streamed downloadable JSON containing ALL retained
  cycles, target searches, graph definitions, user progress, queue, selections,
  answers, and events across app sessions.

Cached-match counts are shared across profiles; cycle/search/presentation counts
are profile-specific. They describe the cache already explored, not corpus-wide
coverage. A zero with no searches is different from an exhausted search. No
previously used-observation filter or new observation-to-word mapping is stored.
The diagnostics history grows with searches and use; it is separate from the
bounded one-result-per-word cache.

## Validation

- Python cache/search tests: 8 passed.
- Real-parser integration: passed. The fixture traversed all three cores,
  reused five observations across 17 answers, exercised a False streak reset,
  checked idempotent answers and completed-target exclusions, checked no repeated
  targets within cycles, and verified the full JSON export.
- Existing audio-validation tests: 4 passed.
- TypeScript typecheck and production frontend/server builds: passed.
- The old `observation-loading.test.ts` suite was also checked. It has three
  source-text assertion failures on BOTH the untouched base and this patch:
  comparison double-click source shape, long-press source shape, and the 500ms
  transition-loader source shape. They are not caused by this patch. Its other
  eleven checks passed. `npm run test:live` runs the focused new-mode/audio gate;
  the historical full suite still includes obsolete weighted/frozen-batch tests.

Not verified here: parsing/search timings, memory and disk growth on the live
275,338-word / 4,111,807-occurrence database, production audio access, or a live Fly
redeployment. No production database or account was modified.
