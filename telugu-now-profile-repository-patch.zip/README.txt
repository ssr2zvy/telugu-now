Telugu-now — profile repository patch

Base: main at 809b851da7f4e4f84173d3b456a11601b3f9823c

Apply ONE way:
1. Copy the contents of replacement-files/ into the repository root, preserving
   the upa/ paths. Add the new files as well as replacing existing files.
OR
2. From the repository root:
   git apply --check /path/to/changes.patch
   git apply /path/to/changes.patch

Do not apply both methods. If main has changed since this base, review conflicts
instead of forcing replacements over newer work. Commit the source changes and
use your existing deployment workflow. This ZIP has not been pushed or deployed.

Included
- Repository icon beside Settings; per-profile folders and plain text documents.
- Icon-only create, file/folder choice, rename, delete and confirmation controls.
- Confirmed folder deletion recursively removes its contents.
- Custom Telugu keyboard for names and documents.
- Documents open with the keyboard hidden, white background, black text and
  left alignment. Tap text to position the cursor and show the keyboard.
- Keyboard retains its existing calculated colors. Documents scroll with it open
  or closed. Header controls hide the keyboard, save, copy, go back and close.
- Shared selection-mode key for documents, freestyle and audio-question typing:
  off moves the caret; on selects. Typing replaces the selected range; backspace
  deletes it. Existing custom magnifier and selection handles remain in use.
- Autosave, local unsaved-draft recovery, revision checks and save-as-copy on a
  conflict. Failed saves keep the document open rather than discarding changes.

Storage
The application automatically creates repository_entries in its existing user
SQLite database. With the current Fly configuration this is
/data/user/users.sqlite on the mounted volume. No secret, new volume or manual
migration command is required. Existing access gating and profile setup remain.
Files are limited to 1,000,000 UTF-8 bytes, names to 200 UTF-16 code units, and
folder ancestry to 64 levels. Names are unique within each directory.

Validation
- Production frontend/backend build and TypeScript checks passed.
- 12 focused tests passed (repository storage/routes, draft saves, keyboard
  geometry and existing reading-tool rendering).
- Mobile-size Chromium interaction checks passed: create, rename, confirmed
  recursive delete, keyboard activation, white/black styling, autosave, custom
  caret/selection, deleting/replacing selected text, scrolling, and shared
  freestyle/question keyboard modes.
- Patch applied cleanly against the base in an isolated Git index; every output
  matched the replacement-file bytes.
- Physical iPhone/iPad testing was not available.

Contents: changes.patch, replacement-files/, manifest.json, this README.
