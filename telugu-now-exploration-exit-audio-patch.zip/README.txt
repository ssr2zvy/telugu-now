Exploration exit audio patch
Base: main 3d73b82129984aaa32c591eee9c3349395e216f5

First reverse scroll exits random letter/word exploration and resets its draws,
showing the full observation with the audio bar hidden. A second scroll opens
its audio bar through the existing handler.

Apply ONE method on a feature branch based on main:
- Copy replacement-files/ contents into the repository root, preserving paths.
- Or run git apply --check changes.patch, then git apply changes.patch.
Merge the feature branch into main through your normal process.

Also: each distinct Telugu grapheme must appear before any letter repeats.
Duplicate positions of the same letter count as one identity (NFC normalized).
After all distinct letters have appeared, unrestricted repeats are allowed.
Word draws do not consume letter coverage. Exiting resets letter coverage.
The existing letter/word probability schedule is preserved.

Two source files and one test file changed.
Typecheck, all 8 random-exploration tests, and git diff --check passed.
Patch application verified against the exact base. No physical device test.
Nothing pushed or deployed.
