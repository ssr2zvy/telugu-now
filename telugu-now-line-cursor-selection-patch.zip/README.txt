Telugu Now — line cursor and selection follow-up
Base: main e79042c27a8fb2ff475668be02494fcd9827ba10
The preceding editor-selection-and-navigation patch is already present in this base.

Apply ONE option from the repository root:
  git apply --check /path/to/changes.patch
  git apply /path/to/changes.patch
OR copy replacement-files/ contents over the repository root. Do not do both.

Changes:
- Taps after a sentence or wrapped line move to that row's end.
- Real empty lines between paragraphs, including consecutive newlines, are valid
  cursor destinations. Taps outside any text row do not relocate the cursor.
- Hard-newline offsets stay attached to the correct row; soft-wrap line ends
  retain their upstream cursor position.
- Multi-line selection measures the complete selected DOM range, rather than
  joining individual shaped Telugu character fragments. Each row combines its
  leftmost and rightmost bounds, preventing clipped/misaligned left edges.
- Existing keyboard controls, saved files, navigation and autosave remain.

Validation:
- Production client/server build and typecheck passed.
- 39 focused tests passed, including paragraph rows, line ends and leftward
  selection fragments.
- Mobile-sized Chromium interaction checks passed: real blank paragraphs,
  soft-wrap ends, final punctuation, ignored space below the document, and
  full-range highlight bounds matching the rendered text.
- Not tested on a physical iPhone/iPad; no claim of device-level verification.

No dependency change, migration or data reset. Not pushed or deployed.
