# Reader controls patch

For ssr2zvy/telugu-now grammar commit 2ba2b3ed293e7f70fb4a03e102f8c0e19f1e50fe. This base already includes the gradient-travel patch.

## Apply

From the repository root:

```sh
git apply --check /path/to/reader-controls-fix-patch/changes.patch
git apply /path/to/reader-controls-fix-patch/changes.patch
cd upa
npm run build
```

Use the patch or the changed-files replacements, not both. No database, volume or progress reset. Nothing was pushed or deployed.

## Changes

- Saved comparison switches remain disabled. Suppress native selection, touch callouts, tap highlighting and pointer-down defaults on locked evaluations, preserving the displayed answer and editable draft behavior.
- Remove the transient Opening profile message during passcode submission. Keep error messages.
- Keep the record control independent of audio visibility and the comparison switch visible while loading. Audio reveal/hide animations no longer move the record control. Phase transition animations remain.
- Share one audio visibility state and vertical swipe handler across reader pages. Down reveals the bar, another down opens controls; up closes controls, then hides the bar. Record controls and switches remain visible. Audio-given questions no longer force the bar to stay visible.
- Audio bars and sliders own gestures beginning on them until release, even outside their bounds. These drags neither navigate nor preview gradient travel. Evaluation controls also do not initiate page swipes. Gestures elsewhere retain page navigation.

## Validation

13 focused tests passed, including long audio drags in all directions after leaving the control, normal page/button swipes and gradient motion cancellation. Production build and whitespace checks passed. Clean-index patch application verified; applied files match replacements.

Physical iPhone and browser visual verification remain outstanding. The removed login message is confirmed in source; a separate OS-provided symbol would need a screenshot to identify. Logs included.
