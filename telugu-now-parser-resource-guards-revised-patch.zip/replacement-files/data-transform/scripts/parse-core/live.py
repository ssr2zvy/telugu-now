#!/usr/bin/env python3
"""One serialized, bounded worker; only frequencies.parse_result caches word parses.
No sentence/context parsing, occurrence copies, or used-observation exclusions.
"""
import argparse
import atexit
import gc
import os
import select
import subprocess
from collections import Counter, defaultdict
import hashlib
import inspect
import json
from pathlib import Path
import random
import sqlite3
import sys
import time
import unicodedata

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'parser'))
from core_parser import CoreParser

# Per object/searchId, across all 16-word batches. A scheduling change must not
# invalidate the on-volume word cache (live.py is excluded from its fingerprint).
NO_MATCH_PARSE_LIMIT = 2500


def compact(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'))


def resolved_targets(result, graph):
    # Multiple targets from ONE resolved analysis are permitted. Ambiguity is not.
    if result.get('separation') != 'resolved_in_model':
        return dict(status='no_parse', reason=result.get('separation', 'unresolved'), targets=[])
    alias = graph['original_to_selectable']
    targets = set()
    for v in result.get('vocabulary_expression_matches', []):
        tid = alias.get('VOC:' + v['id'], 'VOC:' + v['id'])
        if tid in graph['nodes']:
            targets.add(tid)
    for a in result['analyses']:
        tid = alias.get('CHAIN:' + ','.join(a['chain']))
        if tid in graph['nodes']:
            targets.add(tid)
    return dict(status='parsed', targets=sorted(targets)) if targets else dict(status='no_parse', reason='no_core_target', targets=[])

def positive_setting(name, default):
    value = int(os.environ.get(name, default))
    if value <= 0:
        raise ValueError(name + ' must be positive')
    return value


def patterns_for(parser, graph):
    forms = defaultdict(set)
    alias = graph['original_to_selectable']
    for word, records in parser.index.items():
        for record in records:
            tid = alias.get('CHAIN:'+','.join(record['chain']))
            if tid:
                forms[tid].add(unicodedata.normalize('NFC', word))
    for tid, target in graph['nodes'].items():
        if target['kind'] == 'vocabulary':
            forms[tid].update(unicodedata.normalize('NFC', s) for s in target.get('forms', []))
    patterns = {}
    for tid, target in graph['nodes'].items():
        realizations = [s for s in forms[tid] if s and not any(c.isspace() for c in s)]
        needles = sorted(set(s if target['kind']=='vocabulary' else s[-2:] for s in realizations))
        patterns[tid] = dict(needles=needles, maxCodepoints=max([len(s) for s in realizations], default=0),
                             scope='registered-single-word-realizations')
    return patterns, forms


def memory_ceiling(megabytes, hard_megabytes=None):
    # Linux/Fly: a hard address-space limit rejects allocations before the child
    # can exhaust the machine. Do not silently run unbounded on unsupported hosts.
    import resource
    resource.setrlimit(resource.RLIMIT_AS, (megabytes*1024*1024, (hard_megabytes or megabytes)*1024*1024))


def parser_child():
    # If the coordinator is killed (including the old outer watchdog), this child
    # must die too, rather than surviving to overlap a replacement parser index.
    import ctypes
    import signal
    parent = os.getppid()
    if sys.platform != 'linux':
        raise RuntimeError('Isolated parsing requires Linux process resource limits')
    if ctypes.CDLL(None).prctl(1, signal.SIGKILL, 0, 0, 0) != 0:
        raise RuntimeError('Could not install parser parent-death protection')
    if parent == 1 or os.getppid() != parent:
        return
    memory_ceiling(positive_setting('GRAMMAR_PARSE_MEMORY_MB', 512))
    parser = CoreParser()
    graph = json.loads((HERE / 'graph.json').read_text())
    patterns, forms = patterns_for(parser, graph)
    print(compact(dict(ready=True, patterns=patterns)), flush=True)
    del forms, patterns
    gc.collect()
    gc.freeze()  # Do not rescan the permanent index when collecting each word.
    emergency = bytearray(64*1024)
    for line in sys.stdin:
        request = json.loads(line)
        try:
            result = resolved_targets(parser.analyze(request['word']), graph)
            parser._productive_cache.clear()
            # Recursive parse closures can form cycles; release them between words.
            gc.collect()
            print(compact(dict(result=result)), flush=True)
        except MemoryError:
            del emergency
            # Keep the message small; exit to release every allocator/cache page.
            print('{"resourceLimit":"memory-limit"}', flush=True)
            return


class GuardedParser:
    """One persistent index process, supervised independently for every word."""
    def __init__(self, command=None, word_timeout_ms=None, startup_timeout_ms=None):
        self.command = command or [sys.executable, str(HERE / 'live.py'), '--parse-child']
        self.word_timeout = (word_timeout_ms or positive_setting('GRAMMAR_WORD_TIMEOUT_MS', 10000))/1000
        self.startup_timeout = (startup_timeout_ms or positive_setting('GRAMMAR_PARSE_STARTUP_TIMEOUT_MS', 90000))/1000
        self.memory_mb = positive_setting('GRAMMAR_PARSE_MEMORY_MB', 512)
        self.process = None
        self.buffer = bytearray()
        self.patterns = {}
        self.start()
        atexit.register(self.close)

    def read(self, seconds):
        deadline = time.monotonic()+seconds
        while True:
            if b'\n' in self.buffer:
                line, _, tail = self.buffer.partition(b'\n')
                self.buffer = bytearray(tail)
                return json.loads(line)
            remaining = deadline-time.monotonic()
            if remaining <= 0:
                raise TimeoutError('Parser response exceeded its budget')
            if not select.select([self.process.stdout], [], [], remaining)[0]:
                raise TimeoutError('Parser response exceeded its budget')
            chunk = os.read(self.process.stdout.fileno(), 65536)
            if not chunk:
                raise RuntimeError('Parser child exited before replying')
            self.buffer.extend(chunk)
            if len(self.buffer) > 16*1024*1024:
                raise RuntimeError('Parser reply exceeded its size limit')

    def start(self):
        self.close()
        self.process = subprocess.Popen(self.command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=sys.stderr)
        try:
            message = self.read(self.startup_timeout)
            if not message.get('ready'):
                raise RuntimeError('Parser child did not initialize')
            self.patterns = message['patterns']
        except BaseException:
            self.close()
            # Startup failures are infrastructure failures, not evidence about a word.
            raise

    def close(self):
        process, self.process = self.process, None
        self.buffer.clear()
        if process:
            if process.poll() is None:
                process.kill()
            process.wait()
            process.stdin.close()
            process.stdout.close()

    def parse(self, word):
        if self.process is None:
            self.start()
        try:
            self.process.stdin.write((compact(dict(word=word))+'\n').encode())
            self.process.stdin.flush()
            message = self.read(self.word_timeout)
            if 'resourceLimit' in message:
                reason = message['resourceLimit']
            else:
                return message['result']
        except TimeoutError:
            reason = 'time-limit'
        except (BrokenPipeError, RuntimeError, ValueError, KeyError):
            # A signal/EOF alone cannot establish OOM. Preserve the distinction.
            reason = 'worker-interrupted'
        self.close()
        return dict(status='resource_limit', reason=reason, targets=[],
                    occurredAt=int(time.time()*1000), memoryLimitMB=self.memory_mb,
                    timeLimitMs=round(self.word_timeout*1000))


class LiveParser:
    def __init__(self, frequency, corpus, availability, validation=None, parser=None):
        # Tests may inject a tiny parser; production always uses the isolated child.
        self.parser = parser
        self.runner = None if parser is not None else GuardedParser()
        self.graph = json.loads((HERE / 'graph.json').read_text())
        self.db = sqlite3.connect(Path(frequency).resolve().as_uri() + '?mode=rw', uri=True)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA busy_timeout=5000')
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA journal_size_limit=4194304')
        self.db.execute('PRAGMA cache_size=-8192')
        self.source = sqlite3.connect(Path(corpus).resolve().as_uri() + '?mode=ro', uri=True)
        self.source.row_factory = sqlite3.Row
        self.source.execute('ATTACH DATABASE ? AS frequency', (Path(frequency).resolve().as_uri()+'?mode=ro',))
        self.source.execute('ATTACH DATABASE ? AS availability', (Path(availability).resolve().as_uri()+'?mode=ro',))
        self.validation_path = validation
        self.validation = None
        if validation and Path(validation).exists():
            self.validation = sqlite3.connect(Path(validation).resolve().as_uri()+'?mode=ro', uri=True)
        meta = self.db.execute('SELECT * FROM metadata').fetchone()
        if meta is None:
            raise ValueError('Frequency metadata is missing')
        # Do not hash/rewrite the gigabyte corpus on startup. Compare the saved size
        # and mtime identity; these are the fields in the existing frequency builder.
        identity = json.loads(meta['identity'])
        canonical = identity.get('canonical', [])
        stat = Path(corpus).stat()
        if len(canonical) >= 5 and (canonical[3] != stat.st_size or abs(canonical[4] - stat.st_mtime_ns/1e6) > 2):
            raise ValueError('Frequency corpus identity is stale; rebuild frequency before live parsing')
        columns = {r['name'] for r in self.db.execute('PRAGMA table_info(frequencies)')}
        if 'parse_result' not in columns:
            self.db.execute('ALTER TABLE frequencies ADD COLUMN parse_result TEXT')
        mcols = {r['name'] for r in self.db.execute('PRAGMA table_info(metadata)')}
        if 'parse_cache_version' not in mcols:
            self.db.execute('ALTER TABLE metadata ADD COLUMN parse_cache_version TEXT')
        # Cache identity follows parser rules, not worker counters or scheduling.
        h = hashlib.sha256(b'frequency-live-strict-v2')
        h.update(inspect.getsource(resolved_targets).encode())
        for p in sorted(HERE.rglob('*')):
            if p.is_file() and p.suffix in ('.py', '.json') and '__pycache__' not in p.parts and p.name not in ('live.py','cache-compat.json'):
                h.update(p.relative_to(HERE).as_posix().encode()); h.update(p.read_bytes())
        self.version = h.hexdigest()
        old = self.db.execute('SELECT parse_cache_version FROM metadata').fetchone()[0]
        compat_path = HERE / 'cache-compat.json'
        compatible = json.loads(compat_path.read_text()) if compat_path.exists() else {}
        if old != self.version:
            # Only the exact prior asset fingerprint is eligible for migration.
            if compatible.get(old) != self.version:
                self.db.execute('UPDATE frequencies SET parse_result=NULL WHERE parse_result IS NOT NULL')
            self.db.execute('UPDATE metadata SET parse_cache_version=?', (self.version,))
        # Reuse an existing leading normalized_word index if present.
        indexed = False
        for index in self.db.execute('PRAGMA index_list(occurrences)').fetchall():
            name = index['name'].replace('"', '""')
            cols = self.db.execute('PRAGMA index_info("'+name+'")').fetchall()
            indexed |= bool(cols and cols[0]['name'] == 'normalized_word')
        if not indexed:
            self.db.execute('CREATE INDEX live_occurrences_word ON occurrences(normalized_word)')
        self.db.commit()
        if self.parser is not None:
            self.patterns, self.forms = patterns_for(self.parser, self.graph)
        else:
            self.patterns = self.runner.patterns
        self.db.create_function('unicode_candidate', 2, self.candidate, deterministic=True)
        self.counts = Counter(); self.checked = self.parsed = self.resource_limited = 0
        for row in self.db.execute('SELECT parse_result FROM frequencies WHERE parse_result IS NOT NULL'):
            result = json.loads(row[0]); self.checked += 1
            self.parsed += result['status'] == 'parsed'
            self.resource_limited += result['status'] == 'resource_limit'
            self.counts.update(result['targets'])
        self.total = self.db.execute('SELECT COUNT(*) FROM frequencies').fetchone()[0]
        self.tokens = meta['total_occurrences']
        self.searches = {}

    def candidate(self, word, tid):
        return any(n in word for n in self.patterns[tid]['needles'])

    def stats(self):
        return dict(total=self.total, checked=self.checked, parsed=self.parsed,
                    rejected=self.checked-self.parsed-self.resource_limited,resourceLimited=self.resource_limited, tokens=self.tokens, matches=dict(self.counts),
                    parserVersion=self.version, patterns=self.patterns)

    def observation(self, word, storage_identity, blocked, core=1):
        # Unique observations, not token occurrences. Core 1 samples uniformly
        # from at most five shortest eligible observations. Later cores use all.
        if self.validation is None and self.validation_path and Path(self.validation_path).exists():
            self.validation = sqlite3.connect(Path(self.validation_path).resolve().as_uri()+'?mode=ro', uri=True)
        ordering = 'c.grapheme_count,c.source_id,c.source_key' if core == 1 else 'random()'
        rows = self.source.execute("""SELECT c.*,o.occurrence_index FROM source_rows c JOIN (
            SELECT source_id,source_key,MIN(occurrence_index) AS occurrence_index
            FROM frequency.occurrences WHERE normalized_word=? GROUP BY source_id,source_key
            ) o ON o.source_id=c.source_id AND o.source_key=c.source_key
            WHERE c.audio_object_key<>'' AND c.text NOT IN (SELECT value FROM json_each(?))
            AND EXISTS(SELECT 1 FROM availability.source_complexity_members e
                WHERE e.source_id=c.source_id AND e.source_key=c.source_key)
            ORDER BY """+ordering, (word,compact(blocked)))
        pool = []
        for row in rows:
            if self.validation and self.validation.execute("SELECT 1 FROM audio_validation WHERE storage_identity=? AND object_key=? AND status='invalid'", (storage_identity,row['audio_object_key'])).fetchone():
                continue
            pool.append(row)
            if len(pool) == (5 if core == 1 else 1):
                break
        rows.close()
        if not pool:
            return None
        row = random.choice(pool)
        token = self.db.execute('SELECT * FROM occurrences WHERE occurrence_index=?', (row['occurrence_index'],)).fetchone()
        return dict(source_id=row['source_id'],source_key=row['source_key'],text=row['text'],
                    audio_key=row['audio_object_key'],word=word,occurrence=dict(token),
                    observation_selection=dict(policy='core1-shortest-five-v1' if core==1 else 'all-matching-random-v1',
                        poolSize=len(pool) if core==1 else None,length=row['grapheme_count'],lengthMetric='corpus-grapheme-count'))

    def find(self, request, progress=None):
        tid = request['target']
        pattern = self.patterns[tid]
        state = self.searches.setdefault(request['searchId'], dict(length=0, cached=0, cursor='', checked=0, returned=0, examined=0, limited=0, parsed=0, matching=0, reused=0, seen=set(), returned_words=set()))
        # Shortest word takes priority over cache novelty. At equal length, try
        # unchecked words first, then reuse a saved match. No extra disk index.
        # Cursor uses the row's rank BEFORE parsing; a newly cached unusable word
        # may be revisited once, but is never parsed twice.
        def report(stage, **extra):
            if progress:
                progress(dict(stage=stage, checked=state['checked'], returned=state['returned'],
                    examined=state['examined'], limited=state['limited'], parsed=state['parsed'], matching=state['matching'], reused=state['reused'], **extra))
        report('searching')
        rows = self.db.execute("""SELECT normalized_word,parse_result FROM frequencies
            WHERE (length(normalized_word),parse_result IS NOT NULL,normalized_word)>(?,?,?)
            AND length(normalized_word)<=? AND unicode_candidate(normalized_word,?)
            AND (parse_result IS NULL OR EXISTS(
                SELECT 1 FROM json_each(parse_result,'$.targets') WHERE value=?))
            ORDER BY length(normalized_word),parse_result IS NOT NULL,normalized_word LIMIT 16""",
            (state['length'],state['cached'],state['cursor'],pattern['maxCodepoints'],tid,tid)).fetchall()
        state['returned_words'].update(row[0] for row in rows)
        state['returned'] = len(state['returned_words'])
        report('parsing')
        found = None
        source = 'new-parse'
        batch_started = time.monotonic()
        processed = 0
        for row in rows:
            processed += 1
            word, saved = row
            state.update(length=len(word), cached=int(saved is not None), cursor=word)
            if word in state['seen']:
                continue
            state['seen'].add(word)
            state['examined'] += 1
            source = 'cached-parse' if saved is not None else 'new-parse'
            if saved is None:
                state['checked'] += 1
                if self.runner is not None:
                    result = self.runner.parse(word)
                else:
                    result = resolved_targets(self.parser.analyze(word), self.graph)
                    self.parser._productive_cache.clear()
                if result['status'] == 'resource_limit':
                    state['limited'] += 1
                    self.resource_limited += 1
                self.db.execute('UPDATE frequencies SET parse_result=? WHERE normalized_word=?', (compact(result),word))
                self.db.commit()  # Each finished/interrupted attempt survives the next child failure.
                if result['status'] == 'resource_limit':
                    report('parsing', resourceLimit=dict(word=word, reason=result['reason'],
                           memoryLimitMB=result['memoryLimitMB'], timeLimitMs=result['timeLimitMs']))
                state['parsed'] += result['status']=='parsed'
                self.checked += 1; self.parsed += result['status']=='parsed'; self.counts.update(result['targets'])
            else:
                result = json.loads(saved)
                state['reused'] += 1
            report('parsing')
            if tid in result['targets']:
                state['matching'] += 1
                report('selecting')
                found = self.observation(word, request['storageIdentity'], request.get('blocked', []), self.graph['nodes'][tid]['core'])
                if found:
                    found['matched_targets'] = result['targets']
                    break
            # Other core targets do not count as a match for this request.
            # Check after parsing so a match on word 2,500 can still succeed.
            if state['checked'] >= NO_MATCH_PARSE_LIMIT and state['matching'] == 0:
                break
            # Yield after a slow/interrupted word; do not stack 16 word deadlines
            # inside one request to the Node coordinator.
            if time.monotonic()-batch_started >= 0.25 or result['status'] == 'resource_limit':
                break
        # Commit even when capped: a later attempt can skip these saved misses.
        self.db.commit()
        limited = state['checked'] >= NO_MATCH_PARSE_LIMIT and state['matching'] == 0
        pending = not found and not limited and (processed < len(rows) or len(rows)==16)
        response = dict(row=found,pending=pending,source=source,checked=state['checked'],
                        stopReason='word-limit' if limited else 'matched' if found else None if pending else 'exhausted',
                        returned=state['returned'],examined=state['examined'],limited=state['limited'],parsed=state['parsed'],matching=state['matching'],reused=state['reused'],
                        matchedWords=self.counts[tid],pattern=pattern,stats=self.stats_summary())
        if not pending:
            self.searches.pop(request['searchId'], None)
        return response

    def stats_summary(self):
        return dict(total=self.total,checked=self.checked,parsed=self.parsed,rejected=self.checked-self.parsed-self.resource_limited,resourceLimited=self.resource_limited,
                    tokens=self.tokens,matches=dict(self.counts),parserVersion=self.version)


def main():
    if sys.argv[1:] == ['--parse-child']:
        parser_child()
        return
    # Separate the small SQLite coordinator from the large grammar index.
    supervisor_mb = positive_setting('GRAMMAR_COORDINATOR_MEMORY_MB', 128)
    memory_ceiling(supervisor_mb, max(supervisor_mb, positive_setting('GRAMMAR_PARSE_MEMORY_MB', 512)))
    ap=argparse.ArgumentParser()
    for name in ('frequency','corpus','availability','validation'):
        ap.add_argument('--'+name, required=name!='validation')
    args=ap.parse_args()
    worker=LiveParser(args.frequency,args.corpus,args.availability,args.validation)
    print(compact(dict(ready=True,stats=worker.stats())),flush=True)
    for line in sys.stdin:
        request=json.loads(line)
        try:
            result=worker.find(request, lambda progress: print(compact(dict(id=request['id'],progress=progress)),flush=True)) if request['action']=='find' else worker.stats()
            print(compact(dict(id=request['id'],result=result)),flush=True)
        except Exception as e:
            print(compact(dict(id=request['id'],error=str(e))),flush=True)

if __name__=='__main__':
    main()
