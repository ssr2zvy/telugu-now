Telugu Now — revised parse-attempt limit and resource isolation
Base main: 0521b762d03c12a9a5773c4a11137180e0e8b884

This ZIP supersedes telugu-now-search-2500-word-limit-patch.zip. It contains BOTH
that functionality and the new individual-word resource protection.

Choose ONE installation method from the repository root:
A. If the earlier 2,500-limit patch has NOT been applied:
   git apply --check /path/to/changes.patch
   git apply /path/to/changes.patch
B. If the exact earlier 2,500-limit patch HAS already been applied:
   git apply --check /path/to/after-2500-limit.patch
   git apply /path/to/after-2500-limit.patch
C. Alternatively, copy all CONTENTS of replacement-files/ into the repository
   root, preserving paths and including new files. These are final replacements
   for either of those starting states. Do not combine installation methods.
Do not deploy ZIP contents alone: apply the source changes and build/deploy main
through your usual workflow. Nothing has been pushed or deployed by this task.

Behavior
- The object search stops after 2,500 actual parse invocations without a match for
  that object. Cached results do not consume this budget. Abandoned invocations do.
- A valid match on attempt 2,500 still succeeds. A parse into a different object
  does not count as a match for the requested object.
- A capped starting item is replaced by another random eligible item.
- A capped later item is replaced by another neighbor of the previous successful
  item. Preserve the successful chain prefix. If no eligible neighbors remain,
  end the chain and start another. Existing completed/visited/pending rules apply.

Individual word protection (enabled by default, no secrets needed)
- One persistent parser child holds the grammar index. The lightweight Python
  coordinator handles SQLite, search position, and the word watchdog separately.
- The child has a Linux-enforced 512 MiB virtual-address-space ceiling, including
  its grammar index and temporary parse allocations. It is not 512 MiB EXTRA
  per word, and is not an RSS measurement.
- A word gets 10 seconds after child initialization. If its response is too slow,
  the coordinator kills and reaps that child. A denied memory allocation produces
  a memory-limit interruption and the child exits. Unexpected EOF/crashes are
  recorded as worker-interrupted, without claiming that they were proven OOM.
- Continue at the next candidate for the SAME core object; lazily reload one
  parser child. Do not discard the chain just because one word hit its budget.
- Successful words reuse the existing child/index. Temporary parse caches are
  cleared and cyclic garbage collected between words.
- A child is killed automatically if its coordinator dies, preventing an orphan
  parser from overlapping the next worker after the outer watchdog fires.
- Node serializes worker requests so a waiting profile's timer does not expire
  merely because another profile is using the parser.
- After a slow or interrupted word, yield the batch instead of accumulating
  sixteen individual time budgets inside one coordinator request.
- The SQLite coordinator itself has a 128 MiB soft address-space ceiling.

Persistent records and diagnostics
- Each completed or interrupted word is committed immediately to
  /data/corpus/frequency.sqlite, frequencies.parse_result.
- Interrupted records have status resource_limit, targets [], a reason,
  timestamp, and configured memory/time limits. They are NOT linguistic no_parse
  results. The cache skips them in subsequent searches for this parser version,
  preventing a restart loop on the same word. They remain skipped until cache
  invalidation/reset; increasing a budget alone does not re-run those records.
- Existing completed parse results retain their cache fingerprint and survive.
- Diagnostics show per-search resource-limited attempts and a shared-cache total.
  Word-resource-limit events include the word, reason, budgets, search, and chain,
  and appear in the existing diagnostic export. They are excluded from the
  rejected/no-parse count.
- A nullable limited counter is automatically added to live_searches in the user
  database. Older attempts retain unknown resource-limit counts.

Optional runtime environment overrides (defaults shown)
  GRAMMAR_WORD_TIMEOUT_MS=10000
  GRAMMAR_PARSE_MEMORY_MB=512
  GRAMMAR_PARSE_STARTUP_TIMEOUT_MS=90000
  GRAMMAR_COORDINATOR_MEMORY_MB=128
The normal Fly/Linux defaults work without configuration changes. Local Windows
or macOS execution does not silently disable process protection; this worker
requires Linux. Size memory overrides to leave room for Node and other work.

Practical limits
This protects parser allocations; it is not proof that the previous outage was
OOM, nor a guarantee against memory use elsewhere in the app. The repository
configures a 1 GiB machine. The full index loaded under the 512 MiB ceiling in a
local check (baseline parser peak before this change was about 400 MiB).
Reloading the index after an interrupted word takes time. Startup failures are
infrastructure errors, not recorded as failed words. The existing outer 120-second
coordinator watchdog remains for SQL/IPC failures, and startup has its own budget.
If you already override these timeouts, keep the outer timeout large enough for
child startup plus a word attempt. Matches with unusable observations retain the
existing selection behavior; the 2,500 cap concerns searches with zero target matches.

Validation
- Python live-frequency suite: 24 passed (exact limit, boundary match, caching,
  restart persistence, interrupted-word continuation and counting).
- Python process-resource suite: 6 passed, exercising real Linux denied memory
  allocations, timed-out words, partial replies, unexpected exits, reaping/restart,
  successful child reuse, and startup failure classification with a small fixture.
- Node queue/diagnostic/live-mode suites: 4 passed (seed replacement, neighbor
  replacement, chain exhaustion, progress, mastery, and exports).
- npm run build: passed (TypeScript, frontend, server, packaged worker).
- Full production grammar child initialized all 1,275 object patterns under the
  default memory ceiling. No live deployment or production corpus load test.
- Both full and incremental patches applied cleanly to temporary Git indexes;
  resulting files matched the supplied replacements.

Re-run from repository root:
  python3 upa/tests/live-frequency.test.py
  python3 upa/tests/parser-resource-limits.test.py
Then from upa/:
  node --import tsx --test tests/search-word-limit.test.ts tests/chain-recovery.test.ts tests/live-mode.test.ts
  npm run build
