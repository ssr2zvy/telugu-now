Random exploration patch

Base: main 2fa6b9e65f8e824326da467440cf9c29d409cfa1.
Apply on a feature branch based on main, then merge to main using your normal workflow.
No deployment workflow changes are included. Nothing was pushed or deployed.

Apply ONE method:
1. Copy the files inside replacement-files/ into the repository root, preserving paths.
OR
2. From the repository root, run:
   git apply --check changes.patch
   git apply changes.patch

Behavior
- Hide the audio bar and swipe up to enter exploration as before.
- A fresh draw chooses word versus letter first, then uniformly chooses a matching
  occurrence within the current observation. Repeated choices are allowed.
- Letters are Telugu grapheme clusters, not individual Unicode code points.
- Only letters and words are drawn; growing phrase steps are no longer shown.
- Every component retains its original sentence position and size. Single tap plays
  its existing aligned audio snippet; no automatic playback or exploration audio bar.
- Swipe up draws another selection. Swipe down retraces the generated history;
  going before the first selection exits and restores the observation/audio controls.
- Replaying an existing selection does not consume a random draw or advance the schedule.
- Entering/exiting exploration or switching observation/reader phase clears the sequence.
- Changing settings during a visit takes effect on the next visit, so a running
  schedule always keeps the same endpoints and transition length.

Settings > Observations > Exploration
- Start probabilities: Word and Letter sliders, linked so their sum is 100%.
- End probabilities: Word and Letter sliders, linked so their sum is 100%.
- Transition draws: 2–200, default 20.
- Defaults: start 20% word / 80% letter, end 80% word / 20% letter.
- Draw 1 uses the start; draw N reaches the end. Intermediate probabilities change
  linearly, regardless of distance between endpoints. Later draws keep the end state.
  Example: with N=20 the interpolation fraction is (drawNumber-1)/19, capped at 1.
- Preferences use the existing per-profile persistence; no manual database migration.

Validation
- npm run build: passed (typecheck + client + server).
- node --import tsx --test tests/random-exploration.test.ts tests/exploration-layout.test.ts tests/exploration-steps.test.ts: 13 passed.
- git diff --check: passed.
- No iPhone/iPad visual or gesture-device test was performed.

The older ordered-sequence helper remains for shared token/offset construction and
its existing tests; the live reader now uses RandomExploration.
