# Reader navigation, audio layout, deployment and reset patch

Based on ssr2zvy/telugu-now grammar commit ed473bf32f02ff883c97f6e093313cc1ca472451. Apply after the gesture-balance patch, already included in this base.

## Apply

```sh
git apply --check /path/to/reader-navigation-repair-patch/changes.patch
git apply /path/to/reader-navigation-repair-patch/changes.patch
cd upa
npm run build
```

Deploy frontend and backend together. Deploy through ci-cd/deploy.sh (also used by the GitHub workflow) to inject fresh revision, build ID and timestamp. Direct flyctl deployment bypassing that script must supply BUILD_REVISION, BUILD_ID and BUILD_TIMESTAMP build arguments to get the same metadata/cache invalidation. Nothing was pushed, deployed or reset by producing this patch.

## Reader

Settings moves to the top right, keeping its existing appearance and idle fade. Phase icons and the competing navigation arrow are removed from that corner.

Text-given questions cannot reveal an audio bar before a saved recording exists. Saving the recording reveals its bar. Comparison audio remains hidden on entry.

Remove speculative exit animations before server navigation. Failed requests now expose their server error. Incoming phase controls animate once per ready presentation, and position measurements skip those animations to prevent feedback between animation and placement.

Between observations, retain a visual copy of outgoing text while the incoming text prepares. Slide the old and new text in opposite directions using the same duration as background travel. Increase gradient movement from 20 to 180 field units per observation, preserving deterministic Back retracing and the palette. Phase changes within an observation keep text and background stationary. Reduced motion skips sliding. Text copies contain no live controls or audio.

## Appearance

Audio position now works in both directions within safe screen bounds. Magnifier spacing is closer by default. Spacing contains Bar to magnifier (0–48px, default 4) and Timestamp spacing; the optional timestamp is placed on the outer side of the magnifier. Position controls move the group or choose above/below. The legacy audioTimestampGap preference remains compatible but no longer drives layout or appears in the spacing menu.

## Version and deployment

Artifact metadata uses package version plus revision and deployment/build ID. The deploy script passes a fresh timestamp and run/attempt ID, invalidating the build layer even for redeploys of the same commit. Both artifacts receive matching metadata. Version reads use no-store, and the server marks version.json non-cacheable. The timestamp reflects the deployment build, not the exact moment Fly finishes switching traffic. Direct manual build fallback uses local plus timestamp.

## Resets

Current > Reset contains separate pages for Reset chain, Reset current core and Reset all cores. Each describes its effect before the explicit Reset button.

Chain reset preserves mastery. Current-core reset clears that core's streaks/completion and restarts it; at programme completion it restarts Core 3. All-core reset returns to Core 1. Progress resets cancel pending chains and searches, discard pending observations, and retire unapplied batches so stale worker replies or historical answers cannot restore old progress. Other profiles, saved answers and diagnostic history remain. Reset events are recorded. No schema migration is needed.

## Validation

14 focused tests passed: gradient movement, gesture ownership, navigation feedback and profile/core reset isolation. Production build and TypeScript passed. Deployment shell syntax and matching frontend/backend metadata were checked; a second deployment ID on the same revision produced a different version. Patch application to a clean index and replacement-file hashes verified. Logs included.

Physical iPhone/browser visual rendering and a live Fly deployment were not tested. Existing saved answers remain immutable. No application data was changed during validation.
