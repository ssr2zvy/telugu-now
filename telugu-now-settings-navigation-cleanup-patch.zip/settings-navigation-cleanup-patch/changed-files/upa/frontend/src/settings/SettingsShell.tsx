import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from 'react';
import { ChevronDown, ChevronLeft, ChevronRight, PanelLeftClose, PanelLeftOpen, X } from 'lucide-react';
import { settingsGroups, settingsPageLabel, visibleSettingsEntries } from './navigation';
import {
  LanguageIcon,
} from '../components/icons';
import {
  t,
} from './language';
import type {
  SettingsPage,
  UiLanguage,
} from './types';
interface SettingsShellProps {
  language: UiLanguage;
  title: string;
  page: SettingsPage;
  profileCode: string;
  migrationAvailable?: boolean;
  onNavigate: (page: Exclude<SettingsPage, 'index'>) => void;
  onOverview: () => void;
  onBack?: () => void;
  onClose: () => void;
  onToggleLanguage: () => void;
  children: ReactNode;
}
export function SettingsShell({
  language,
  title,
  page,
  profileCode,
  migrationAvailable = false,
  onNavigate,
  onOverview,
  onBack,
  onClose,
  onToggleLanguage,
  children,
}: SettingsShellProps) {
  const [railCollapsed, setRailCollapsed] = useState(true);
  const [collapsedGroups, setCollapsedGroups] = useState<Partial<Record<SettingsPage, boolean>>>(() =>
    Object.fromEntries(Object.keys(settingsGroups).filter(group => group !== 'index').map(group => [group, true])),
  );
  const heading = useRef<HTMLHeadingElement>(null);
  const content = useRef<HTMLDivElement>(null);
  const shell = useRef<HTMLElement>(null);
  const overviewOpen = !railCollapsed;
  const overviewIsFullScreen = page === 'index';
  const railToggleLabel = language === 'en'
    ? (railCollapsed ? 'Show settings menu' : 'Hide settings menu')
    : (railCollapsed ? 'అమరికల మెను చూపించు' : 'అమరికల మెను దాచు');
  useEffect(() => {
    content.current?.scrollTo(0, 0);
    heading.current?.focus({ preventScroll: true });
  }, [page]);
  useEffect(() => {
    const viewport = window.visualViewport;
    if (!viewport) return;
    let frame = 0;
    const updateViewport = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const element = document.activeElement;
        const container = content.current;
        const style = shell.current?.style;
        if (!style || !container) return;
        const editing = element instanceof HTMLElement && container.contains(element)
          && element.matches('input:not([type="checkbox"]):not([type="radio"]):not([type="range"]):not([type="color"]), textarea, select');
        // Follow the keyboard's visible area, but leave deliberate pinch zoom to the browser.
        if (!editing || Math.abs(viewport.scale - 1) > 0.01) {
          style.removeProperty('--settings-viewport-height');
          style.removeProperty('--settings-viewport-top');
          return;
        }
        style.setProperty('--settings-viewport-height', `${viewport.height}px`);
        style.setProperty('--settings-viewport-top', `${viewport.offsetTop}px`);
        const field = element.getBoundingClientRect();
        const bounds = container.getBoundingClientRect();
        const top = bounds.top + 24;
        const bottom = bounds.bottom - 24;
        if (field.top < top) container.scrollBy({ top: field.top - top });
        else if (field.bottom > bottom) container.scrollBy({ top: Math.min(field.bottom - bottom, field.top - top) });
      });
    };
    viewport.addEventListener('resize', updateViewport);
    viewport.addEventListener('scroll', updateViewport);
    document.addEventListener('focusin', updateViewport);
    document.addEventListener('focusout', updateViewport);
    return () => {
      cancelAnimationFrame(frame);
      viewport.removeEventListener('resize', updateViewport);
      viewport.removeEventListener('scroll', updateViewport);
      document.removeEventListener('focusin', updateViewport);
      document.removeEventListener('focusout', updateViewport);
    };
  }, []);

  const navigationButton = (destination: SettingsPage, nested = false) => {
    const label = settingsPageLabel(destination, language);
    return (
      <button
        key={destination}
        className={`settings-rail-link${nested ? ' settings-rail-child' : ''}`}
        type="button"
        aria-current={page === destination ? 'page' : undefined}
        onClick={() => {
          if (page !== destination) {
            if (destination === 'index') onOverview();
            else onNavigate(destination);
          }
          setRailCollapsed(true);
        }}
      >

        <span>{label}</span>
      </button>
    );
  };
  const navigationGroup = (group: SettingsPage, depth = 0): ReactNode => (
    <div className="settings-rail-group" key={group} style={{'--settings-nav-depth':depth} as CSSProperties}>
      <div className="settings-rail-group-heading">
        {navigationButton(group, depth > 0)}
        {settingsGroups[group] ? <button className="settings-rail-disclosure" type="button"
          aria-label={`${collapsedGroups[group] ? (language === 'en' ? 'Expand' : 'విస్తరించు') : (language === 'en' ? 'Collapse' : 'కుదించు')} ${settingsPageLabel(group,language)}`}
          aria-expanded={!collapsedGroups[group]} aria-controls={`settings-rail-${group}`}
          onClick={() => setCollapsedGroups(current => ({...current,[group]:!current[group]}))}>
          {collapsedGroups[group] ? <ChevronRight size={16} aria-hidden="true"/> : <ChevronDown size={16} aria-hidden="true"/>}
        </button> : null}
      </div>
      {settingsGroups[group] ? <div id={`settings-rail-${group}`} hidden={Boolean(collapsedGroups[group])}>
        {visibleSettingsEntries(group,migrationAvailable).map(child => navigationGroup(child,depth + 1))}
      </div> : null}
    </div>
  );
  return (
    <main
      ref={shell}
      className={`app-shell settings-screen${railCollapsed ? ' settings-rail-collapsed' : ' settings-overview-open'}${overviewIsFullScreen ? ' settings-overview-root' : ' settings-overview-nested'}`}
      lang={language}
    >
      <button
        className="settings-rail-toggle"
        type="button"
        aria-label={railToggleLabel}
        aria-expanded={!railCollapsed}
        aria-controls="settings-rail"
        onClick={() => setRailCollapsed((collapsed) => !collapsed)}
      >
        {railCollapsed ? <PanelLeftOpen size={20} aria-hidden="true" /> : <PanelLeftClose size={20} aria-hidden="true" />}
      </button>
      {overviewOpen && !overviewIsFullScreen ? (
        <button
          className="settings-rail-scrim"
          type="button"
          aria-label={language === 'en' ? 'Close settings menu' : 'అమరికల మెను మూసివేయి'}
          onClick={() => setRailCollapsed(true)}
        />
      ) : null}
      <aside
        className="settings-rail"
        id="settings-rail"
        aria-hidden={railCollapsed}
        {...(overviewOpen && !overviewIsFullScreen ? { role: 'dialog', 'aria-modal': true } : {})}
      >
        <div className="settings-rail-heading">
          <span>{language === 'en' ? 'Profile' : 'ప్రొఫైల్'}</span>
          <span className="settings-profile-code">{profileCode}</span>
        </div>
        <nav aria-label={language === 'en' ? 'Settings navigation' : 'అమరికల నావిగేషన్'}>
          {navigationButton('index')}
          {visibleSettingsEntries('index', migrationAvailable).map(group => navigationGroup(group))}
        </nav>
      </aside>
      <header className="settings-header">
        <div className="settings-heading">
          <h1 ref={heading} tabIndex={-1}>{title}</h1>
        </div>
        <div className="settings-header-side">
          {onBack ? (
            <button
              className="settings-back"
              type="button"
              aria-label={
                t(
                  language,
                  'back',
                )
              }
              onClick={onBack}
            >
              <ChevronLeft size={20} aria-hidden="true" />
            </button>
          ) : null}
        </div>
      <button
        className="settings-close"
        type="button"
        aria-label={t(language, 'close')}
        onClick={onClose}
      >
        <X size={20} aria-hidden="true" />
      </button>

      </header>
      <div ref={content} className="settings-page-content">
        <div className="settings-page-transition" key={page}>{children}</div>
      </div>
      <button
        className="language-toggle"
        type="button"
        aria-label={
          t(
            language,
            'language',
          )
        }
        onClick={
          onToggleLanguage
        }
      >
        <LanguageIcon />
      </button>
    </main>
  );
}
