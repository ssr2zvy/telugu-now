# Settings navigation cleanup

Apply AFTER telugu-now-audio-highlight-refinement-patch.zip, which itself follows telugu-now-reader-navigation-repair-patch.zip. This ZIP contains only the new settings changes. Local prerequisite baseline 8429554441f9d912a03e2e76d8454e4b61aa255c is a packaging reference, not a remote commit to check out.

## Apply

```sh
git apply --check /path/to/settings-navigation-cleanup-patch/changes.patch
git apply /path/to/settings-navigation-cleanup-patch/changes.patch
cd upa
npm run build
```

Frontend-only change. Nothing pushed or deployed.

Remove decorative leading category icons from the settings index, parser/appearance submenu links, data-source entries and navigation overview. Preserve functional trailing disclosure chevrons, font previews, and control icons. Category text uses the freed column.

Move Back immediately left of Close in the header's right-hand slots. The title stays in the left column at every depth, including pages without Back, so its position does not jump.

Randomize already generates palettes from continuous random hue, spread, saturation, individual stop variation and foreground values. It does not select a predefined list and is not limited to thousands of combinations. It uses Math.random pseudorandom sampling; it does not promise globally unique results. No generator change was necessary.

25 appearance/settings tests and the production build passed. Whitespace and clean-index patch application verified; applied files match supplied replacements. Physical iPhone/browser visual validation not performed. Logs included.
