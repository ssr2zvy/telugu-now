#!/usr/bin/env python3
"""Check/apply this reviewed UI patch. No network, database or deployment actions."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', type=Path, required=True)
scope = parser.add_mutually_exclusive_group()
scope.add_argument('--category-only', action='store_true', help='Apply patch 08 after patches 01–07')
scope.add_argument('--parser-only', action='store_true', help='Apply patch 07 to the reviewed parser baseline')
scope.add_argument('--navigation-only', action='store_true', help='Apply patch 06 after patches 01–05')
scope.add_argument('--reader-fixes-only', action='store_true', help='Apply patch 05 after patches 01–04')
scope.add_argument('--question-type-only', action='store_true', help='Apply patch 04 after the earlier UI package')
parser.add_argument('--apply', action='store_true', help='Apply after all checks pass')
args = parser.parse_args()
repo = args.repo.resolve()
package = Path(__file__).resolve().parent
manifest = json.loads((package / 'manifest.json').read_text())
stage_number = 8 if args.category_only else 7 if args.parser_only else 6 if args.navigation_only else 5 if args.reader_fixes_only else 4 if args.question_type_only else None
selected_stage = next((stage for stage in manifest['stages'] if stage['number'] == stage_number), None)
entries = selected_stage['files'] if selected_stage else manifest['files']
problems = []
for entry in entries:
    path = repo / entry['path']
    before = entry['before_git_blob']
    if before is None:
        if path.exists() or path.is_symlink():
            problems.append(f"New path already exists: {entry['path']}")
        continue
    if not path.is_file() or path.is_symlink():
        problems.append(f"Expected regular source file: {entry['path']}")
        continue
    data = path.read_bytes()
    actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    if actual != before:
        problems.append(f"Source differs from reviewed version: {entry['path']}")
if problems:
    parser.exit(1, '\n'.join(problems) + '\nRebase the patch onto these changes before applying.\n')
patch = package / selected_stage['patch'] if selected_stage else package / 'patches' / 'combined.patch'
subprocess.run(['git', 'apply', '--check', str(patch)], cwd=repo, check=True)
if not args.apply:
    print('Checks passed. Run the same command with --apply to apply the reviewed patch.')
else:
    subprocess.run(['git', 'apply', str(patch)], cwd=repo, check=True)
    for entry in entries:
        actual = hashlib.sha256((repo / entry['path']).read_bytes()).hexdigest()
        if actual != entry['after_sha256']:
            raise SystemExit(f"Post-apply hash mismatch: {entry['path']}")
    print(f"Applied and verified {len(entries)} files. No commit or deployment performed.")
