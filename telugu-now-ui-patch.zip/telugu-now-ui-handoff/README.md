# Telugu-now UI patch

For `ssr2zvy/telugu-now`, branch `grammar`, reviewed commit:
`918cb58112dc0005eaf3bea2bc9c147ef544e28f`.

This ZIP contains four ordered patches, a combined alternative, and the complete changed files for reference. Apply it to the repository; it is not a replacement repository. Keep the existing `data/`, databases, assets, environment configuration and deployment files.

## Changes

1. **Shared control material:** palette-colored icon gradients, clearer hover/press/selected states, transparent button backgrounds, shared corner-icon colors. Existing geometry and hit areas remain.
2. **Audio and Settings:** keep the existing scrubber progress/window gradients and recording animation; remove only the main scrubber's thin baseline. Refine the 11px cursor's paint. Fix the magnifier to one second (the whole clip if shorter), with roughly 4px waveform bars and 2px gaps derived from actual audio. Settings uses the same material; every existing route and control is retained.
3. **Login, grading and nitpicks:** custom three-digit keypad without an editable login input; an initially unanswered True/False selector; asynchronous copy/blacklist feedback; corrected word-only copying; typed-answer font inheritance and scroll affordance; recording readiness feedback; navigation/phase indicator timing; image double-tap handling; comparison-divider paint.

4. **Automatic question-type reversal:** start each grammar category at 2/3 text-given, gradually reverse to 2/3 audio-given, and reset at the existing next-category peak boundary. At final completion hold the audio-heavy endpoint. See `QUESTION-TYPE-CURVE.md` for formula, batch timing and audit fields.

The existing three-digit login auto-submit, evaluation API, final answer locking, per-profile progression and ten-question batches remain. Patches 01–06 preserve the parser. Patch 07 changes parser attachment validation and overlap diagnostics. Grammar target identity policy, progression equations, SQLite schema, Tigris worker and deployment settings are unchanged. Patch 04 updates backend question-type selection and its frontend diagnostics.

## Apply

From the unzipped folder, check the destination:

```sh
python3 apply.py --repo /path/to/telugu-now
```

Then apply:

```sh
python3 apply.py --repo /path/to/telugu-now --apply
```

The helper checks every affected file against its reviewed Git blob, checks new paths are absent, runs `git apply --check`, and applies `patches/combined.patch`. It stops on a mismatch instead of overwriting later work. It does not commit, push or deploy.

If the earlier three UI patches are already applied, add only the new behavior:

```sh
python3 apply.py --repo /path/to/telugu-now --question-type-only
python3 apply.py --repo /path/to/telugu-now --question-type-only --apply
```

This checks and applies patch 04 only. The original three numbered patches are unchanged.

For separate review, apply **01, then 02, then 03, then 04, then 05, then 06, then 07, then 08**, checking each immediately before applying it. Do not apply the combined patch in addition to the numbered patches. `files/` is a reference copy of the final changed files, not a folder to overlay blindly onto newer code.

If affected files have changed since the reviewed commit, ask the implementing agent to rebase the diffs onto those changes. Unrelated files may differ; this package does not replace them.

## Verification

See `VALIDATION.md` for exact results and limits and `NITPICKS.md` for each original item's disposition. Both patch application routes were checked independently against exact GitHub file contents, and all final hashes were verified.

This is a reviewable implementation handoff. Browser/device verification remains pending because Chromium could not be downloaded in the preparation environment. In particular, inspect the grading selector with the audio bar visible and check the custom keypad on a real phone before deployment.

## Reader fixes added in patch 05

Pre-paint reset prevents stale audio controls/animations on text-given pages. Oversized words can wrap between intact graphemes with a visible `-`; browser line fitting, balance and centering include its width. Corpus text, source offsets and copied words remain unchanged. See `READER-FIXES.md`.

If patches 01–04 are already applied:

```sh
python3 apply.py --repo /path/to/telugu-now --reader-fixes-only
python3 apply.py --repo /path/to/telugu-now --reader-fixes-only --apply
```

The first four numbered patches are unchanged. The combined patch includes all eight.

## Navigation timing — patch 06

The corner now has one active navigation sequence. It retains the arrow while the new observation loads, then waits for the 1500ms arrow animation to finish before revealing the phase icon. New navigation/readiness changes invalidate old callbacks. A 1700ms fallback covers reduced motion and missing animation events. Case Study 1 colors and icon geometry remain.

If patches 01–05 are already applied:

```sh
python3 apply.py --repo /path/to/telugu-now --navigation-only
python3 apply.py --repo /path/to/telugu-now --navigation-only --apply
```

Patches 01–05 are byte-identical to the previous ZIP.

## Verified parser attachments and overlaps — patch 07

See `PARSER-ATTACHMENTS.md` for rules, results, coverage limits and rebuilding the derived grammar database. The first six numbered patches are unchanged. Parser files are placed in the reviewed repository's `data-transform/scripts/build-grammar/` path.

To apply only the parser changes against the reviewed parser files:

```sh
python3 apply.py --repo /path/to/telugu-now --parser-only
python3 apply.py --repo /path/to/telugu-now --parser-only --apply
```

## Base-boundary checks and Category settings — patch 08

Settings → Observations → Category shows the active profile's actual reversal curve and available core bases / single-modifier targets. Original probabilities are dashed, current probabilities solid; shading indicates the reversal region. Current-batch probabilities remain frozen until the batch is applied.

Parser dictionary hits no longer bypass ending search. Suspect dictionary base boundaries are reanalyzed, with deeper analyses and strong partial candidates retained in diagnostics and unresolved outer targets excluded. This applies to registered endings and does not automatically supply missing grammar rules. See CATEGORY-AND-BASE-BOUNDARIES.md.

After patches 01–07:

```sh
python3 apply.py --repo /path/to/telugu-now --category-only
python3 apply.py --repo /path/to/telugu-now --category-only --apply
```

Patches 01–07 remain byte-identical.
