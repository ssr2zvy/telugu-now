# Validation results

## Added question-type curve (patch 04)

- 11/11 tests pass: the existing grammar reference comparison plus new within-category reversal, exact reset boundary, consecutive-True gate, False rollback, completion latch, diagnostics and SQLite queue/batch integration checks.
- TypeScript check passes. Both production frontend and backend bundling pass.
- Full combined, ordered four-patch and incremental patch-04 application paths are checked against the exact reviewed source hashes.
- The original three UI patches are byte-for-byte unchanged from the previous ZIP. Their earlier UI validation results and browser limitations remain below.
- No deployment or real-device browser validation was performed.

Run the added/related tests from `upa/`:

```sh
node --import tsx --test tests/grammar-model.test.ts tests/grammar-question-type.test.ts tests/grammar-integration.test.ts
```

On the app, also confirm Diagnostic → Questions displays recorded probabilities, unchanged within the current batch of 10, and updated for the next batch. Existing historical questions must say the curve was not recorded.

## Original UI validation

| Check | Result |
|---|---|
| TypeScript `npm run typecheck` | Passed |
| Frontend production bundle via Vite | Passed, with existing local font assets |
| Focused Node test run | 98 passed; 1 existing source-text test mismatch |
| Numbered patches, applied in order | Passed against exact reviewed GitHub file contents |
| Combined patch, applied independently | Passed; every resulting file hash matches |
| Original UI source scope | Frontend and tests only; patch 04 additionally changes backend question-type selection |
| Browser / real-device visual and interaction checks | Pending; Chromium download timed out and returned HTTP 502 |

## Test scope

The 99-test run covers the new fixed-duration magnifier/window and waveform sampling, login/evaluation initial render contracts, existing audio preparation/encoding and cache behavior, precise seeking calculations, bookmarks, reader double-tap timing, image-navigation state, appearance validation and selected UI contracts. Component-render tests are server-side React tests; they are not browser event tests.

One test remains failing: `word profiles fill the viewport with word and image columns` in `upa/tests/reading-context-menu.test.ts`. It asserts the older letter-profile renderer (`teluguHighlightRuns(grapheme.segment)` and related structures). The reviewed source already uses `selection.text`; this patch changes only async callback types in that component. The baseline checkout also fails that test. The existing renderer was not changed merely to satisfy the stale test. This is not a fully green repository-wide test report.

Several expectations directly affected by this change were updated: the hover preview no longer assumes color inversion, waveform assertions reflect 160 bins/second, the Settings icon uses the shared paint definition, and recording feedback waits for the actual start event. Two stale source-text checks were narrowed to recognize the existing optional glyph-hit guard and avoid mistaking an unrelated later button for an alert child.

Run from `upa/`:

```sh
npm run typecheck
node node_modules/vite/bin/vite.js build --config frontend/vite.config.ts
node --import tsx --test tests/magnifier-waveform.test.ts tests/material-ui.test.ts tests/prepared-audio.test.ts tests/audio-presentation.test.ts tests/audio-normalization.test.ts tests/audio-bookmarks.test.ts tests/reader-taps.test.ts tests/word-image-navigation.test.ts tests/audio-controls.test.ts tests/appearance.test.ts tests/settings-icon.test.ts tests/reading-context-menu.test.ts
```

The browser suite was not run. Its legacy `.profile-input` login setup and assertions about inverted hover colors/empty login text need adapting to the deliberately changed UI before using that suite as a release gate. No browser-test results or screenshots are claimed in this package.

## Checks for the implementing agent

Use desktop and a real mobile device, with a light and dark saved palette:

1. Login: keypad and hardware entry; leading-zero code; backspace and slot correction; paste allowed/denied; invalid/unavailable retry; rapid taps while loading. Verify no OS keyboard opens and the keypad fits in portrait and landscape.
2. Evaluation: initial unanswered state; True and False payloads; duplicate-click lock; failure then retry; saved result after revisiting. Show the audio bar/magnifier at the same time and verify neither is obscured by the selector.
3. Audio: retain the progress/window gradient, remove only the thin main baseline, preserve the recording loop at the cursor endpoint. Check short/long clips and both edges: a one-second magnifier with consistent bar widths. Verify bookmark and seek positions do not drift.
4. Record on a phone after a cold permission request and again with permission granted. “Recording” must start when capture starts; assess onset timing from actual playback. The patch cannot recover speech before microphone capture starts.
5. Copy/blacklist: selected word only; success only after completion; rejection shows retryable feedback. Double-tap image halves with touch and mouse; taps on actions/info/gallery must not navigate.
6. Settings: every existing route, field and toggle remains usable; all keyboard focus indicators visible. Check chosen fonts and long typed answers. On comparison, swipe must not shift either audio bar; navigation feedback and phase icon must not overlap.

The mobile keyboard spacing and modifier-color island reports still need concrete repro examples, as recorded in `NITPICKS.md`. The original UI run did not package the backend. Patch 04 additionally passed backend bundling; worker asset packaging and deployment were not performed.

## Patch 05 reader fixes

- Six new targeted checks pass (plain/highlighted text preservation, grapheme safety, resize/oversized classification, source offsets, pre-paint reset wiring); five presentation checks also pass.
- TypeScript check passes; frontend production build passes.
- Broader observation-loading/presentation/new checks: 24/25 pass. The failing existing source-regex check at observation-loading.test.ts:90 expects `wordAtPoint({ clientX, clientY, target })`; prior patch 03 already passes the additional `true` context-menu argument. Patch 05 does not change that handler.
- No browser/device validation claimed. See READER-FIXES.md for deployment checks.
- Ordered, combined and reader-only patch application/hash checks are recorded in validation/.

## Patch 06 navigation timing

Five navigation-state regression tests plus six reader-fix tests pass (11/11). TypeScript and frontend production build pass. Ordered, combined and navigation-only applications are hash-verified. The first five numbered patches remain byte-identical. Browser/device animation verification remains pending.

## Patch 07 parser

Nine attachment/overlap/integration tests and seven existing progression-policy tests pass. Engine self-tests pass. The integration test runs the actual parser into a temporary derived SQLite and verifies source bytes unchanged and no ambiguous-target credit. No full corpus analysis, Tigris upload, deployment or activation was run. See PARSER-ATTACHMENTS.md for intentional coverage limits.

## Patch 08 Category / deeper base checks

11 parser/SQLite tests and eight category-curve tests pass. TypeScript and frontend build pass. Ordered, combined and patch-08-only application are hash-verified. Browser/device verification and full-corpus coverage remain pending.
