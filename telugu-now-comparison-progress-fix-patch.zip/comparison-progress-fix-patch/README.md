# Comparison progression repair

Base: ssr2zvy/telugu-now grammar bd31569f4e881b96944a628ec5d2787a393196b4.
Apply AFTER the latest recording-layout-complete patch, already present in this base. This ZIP contains only the new fixes.

## Apply

From the repository root:

```sh
git apply --check /path/to/comparison-progress-fix-patch/changes.patch
git apply /path/to/comparison-progress-fix-patch/changes.patch
cd upa
npm run build
```

Use changes.patch or changed-files replacements, not both. Deploy frontend and backend together. No database reset, migration or progress deletion. Nothing pushed or deployed.

## Confirmed cause

navigateNext advanced comparison to observation, then getProfileState immediately rewound an unanswered observation to comparison. The API returned success but the page stayed the same. In addition, canNext was false for an unanswered normal observation even though the frontend needs to submit its answer on leaving that page.

Remove that premature rewind and permit the frontend to finalize the draft when leaving the observation. Keep the server guard against moving to another observation without a saved answer. Back/forward between comparison and observation does not finalize a draft. Saved true/false answers remain immutable.

## Gesture and stalled-request recovery

Deliberate swipes starting on the evaluation control now navigate; taps retain their switch behavior. The click following a swipe is suppressed so a swipe cannot change the answer. Audio-seeking gesture ownership is preserved.

Bound navigation and state refresh operations, including reading the response body, to 15 seconds. Navigation already had an abort signal; the new deadline also settles the caller even if the underlying operation does not respond to cancellation. Polling can resume after a hung refresh. Bound recording saves to 45 seconds and reuse the existing retained-blob retry behavior. The existing finally paths release request/navigation locks and navigation errors remain visible. Mutations are never automatically retried.

These changes address confirmed code paths, not a claim that every device-specific freeze has been reproduced. A timed-out mutation may have reached the server; normal state polling reconciles it. Physical iPhone gesture and intermittent-network verification remains outstanding.

## Validation

Regression failed on the original branch: expected observation, received comparison. It now passes, including repeated polling, backward/forward movement, saved false answers, and the guard against leaving without evaluation. Deadline tests cover hung requests, late completion, retry, and abort. Gesture tests include the evaluation control and preserve audio seeking.

11 focused tests and the production frontend/backend build (including TypeScript) passed. Clean-index patch application verified and every replacement checked against its applied hash. Logs included.
