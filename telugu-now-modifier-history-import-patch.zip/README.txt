Modifier history, omissions and import patch
Base: main 9361d2284c8a796f4574530414737cb4325f63d5

Apply changes.patch at repository root with git apply changes.patch, or copy the
contents of files/ over the repository. Commit all changes, including package-lock.json.
Install dependencies with npm ci in upa, build, then use your existing deploy workflow.

Includes supplied archive schema 1.10: 173 entries, 321 examples.
- Back/forward preserves history; only beyond latest draws randomly.
- Inline zero-pool reset preserves permanent ??? omissions.
- Long press reveals ???; omitted entries can be restored in Modifier mode settings.
- Per-profile ZIP import replaces the active catalog and starts a new round.
- Omissions match stable grammar IDs and persist on the volume through resets/imports.

Validation: production build; 8 focused tests; simulated React DOM integration.
Not tested on a physical iPhone. Does not change or diagnose the outstanding
service-starting deployment issue. See upa/docs/modifier-mode.md for details.
