# Observations settings patch

Base: grammar branch 0837b30fe459375fdb10dea57d656b8014c07828. This is a separate settings-only patch. It can be applied alongside telugu-now-text-comparison-swipe-patch.zip; they modify different source files. No database migration or parser change.

Apply from the repository root:

```sh
git apply --check /path/to/changes.patch
git apply /path/to/changes.patch
cd upa
npm run build
node --import tsx --test tests/parser-settings.test.ts
```

Alternatively copy changed-files/ to the corresponding repository paths. Use only one application method.

## Navigation

- Observations
  - Parser
    - Current
    - Diagnostics
      - Download
      - Queue, Data Sources, Blacklist, Reset Queue
  - Questions

Observations and Parser immediately display their submenus. Back returns to the immediate parent. The side menu supports the full hierarchy.

## Current

Current core, mastered-object completion across all three cores, current-core completion, saved matched word highlighted in its observation, and the loaded chain in selection order. The current step is indicated. Chain entries use the inventory's Telugu forms or the parser's actual Unicode search needles. Missing needles display “Unicode unavailable”; internal modifier IDs are not substituted. No speculative future connections are invented. The chain's core is shown separately from the profile's current core when revisiting older observations. Per-core progress expands on demand. Completion is measured by fully mastered objects, not partial streaks.

## Diagnostics

Objects sorted by fewest cached matching words. Core, search, no-match and not-shown filters; lists use 30-item pages. Object details expand to reveal search counts, lengths, Unicode rules and internal identifiers. Preparation, word-cache totals, cycle totals and end reasons, recent events, selection evidence and technical records are collapsed by default. Full history remains downloadable as JSON without date/row limits. Events load when expanded. Summary data refreshes every three seconds; last successful data remains visible on errors.

## Questions

One slider sets audio-given probability, with its complementary text-given percentage. Save affects new selections only; queued types remain unchanged. Controls wait for saved settings to load before becoming editable.

## Presentation

Scoped settings typography: consistent menu-scale headings, muted supporting text, normal document spacing, theme-aware word highlighting, restrained progress tracks, native keyboard-accessible disclosures, and existing menu/action components. Large tables and repeated explanatory headings are replaced with compact expandable rows. No visual changes to reader, audio, recording or comparison pages.

## Validation

See validation.txt. Browser rendering and physical iPhone layout were not verified in this environment.

## Acceptance checks

Open Observations: Parser and Questions are immediately visible. Open Parser: Current and Diagnostics are visible. Confirm parent Back behavior and nested side-menu navigation. Check Current on a loaded chain and on an older observation. Expand a diagnostic target and verify Unicode rules and identifiers. Search/filter/page through coverage. Download the full JSON. Save question mix at 0%, 50%, and 100%, reopen and verify persistence. Check narrow/mobile layout and keyboard disclosure controls.
