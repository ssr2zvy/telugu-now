# Next chain search, settings, and reader gestures

Patch for `ssr2zvy/telugu-now`, grammar branch, based on `976ae94d9c8e6e37e51364ae44be8fd36bda162c`.
The previously supplied chain-recovery ZIP is already included in this base.
This ZIP contains only the subsequent changes. Nothing has been pushed or deployed.

## Apply

From the repository root on the grammar branch:

```sh
git apply --check /path/to/changes.patch
git apply /path/to/changes.patch
cd upa
npm run build
```

Deploy frontend and backend together. The worker assets, including `cache-compat.json`, must be packaged with the server; the normal build already does this.
`changed-files/` is provided for review. Prefer the patch: it also removes the two obsolete diagnostics components listed in `deleted-files.txt`.

## Reader

- A permanent bottom-right settings icon uses the same material, color, stroke, and visible size as the top-right phase mark, with a 44px touch target.
- Removed the reader's long-press/context menu and triple-tap settings shortcut, including the text copy menus in word/letter inspection. Separate image-gallery controls remain.
- Background navigation/disclosure double-clicks are removed. Word/letter inspection double-taps remain.
- Page swipes can start over the audio bar, magnifier, switch, recording button, and question controls. A deliberate page swipe takes over from the underlying control; taps and short control drags still operate the control.
- Keyboard navigation and comparison answer commits remain. Failed navigation/evaluation requests time out instead of holding navigation indefinitely. Comparison font/gradient failures no longer leave readiness permanently false.

## Settings

- Observations contains Parser, Questions, and Data Sources.
- Parser contains Current and Diagnostics.
- Current: overview, Chain, Next chain search, Reset, Progress by core.
- Diagnostics: Object coverage, Search and parse, Cycle history, Events, Parser details.
- Search and parse separates Current searches from All-time searches. Current searches uses the same data/view as Next chain search.
- These subsections are pages, with back navigation. Navigation rows have no subtitles. Header positions and reserved back-arrow space stay consistent.
- Event download includes observations, selections, chain cycles, searches, answers, history, and discarded-observation records.

## Next chain search

- Guider: “Generating chain” / “No chain to generate”. Lists the actual generated chain selections; future connections are added as matches are found, never fabricated in advance.
- Searcher: “Searching core [number] · [Unicode]” / “No core in queue to search”.
- Parser: “Parsing searches” / “No searches to parse”.
- Ordered chain entries open their search/parse attempt as a separate page. Last search and parse attempt has its own page.
- Each attempt records timestamps, search request result, words returned, words examined, fresh parser evaluations, fresh successful parses, cached results examined, requested-object matches, selected word, stop reason, and any error.
- Words returned counts unique candidates fetched in this attempt, including candidates not evaluated because an earlier match stopped the pass. Words examined includes cached candidates. Successful fresh parses may match a different core object; requested-object matches are counted separately.

## Totals and persistence

- Profile totals: successful word searches (playable matches, including cached matches) and words examined (repeat examinations in different searches count again).
- Shared cache totals: distinct words with a valid parse and distinct word-to-object matches, for the saved parser version.
- Older search rows retain their original fresh-evaluation counts. New fields are unknown for those rows, not invented zeros. The UI states when examination tracking began.
- Additive SQLite migrations run automatically. A lightweight saved cache summary remains visible while the worker is idle; the first load can read existing frequency-cache totals without launching the parser.
- This diagnostics-only worker change preserves the exact previous parser asset cache using a fingerprint-checked compatibility migration. Unrecognized/incompatible parser caches still invalidate normally.

## Reset

Reset marks the displayed chain discarded, removes its unused selections from the queue, and prevents its in-flight result from becoming another selection. Answers, mastery, displayed history, and diagnostics remain. Discarded unanswered observations cannot later change progress.
Selections already gathered for another chain survive. The next prepared chain opens immediately; otherwise the reset waits persistently and opens it when ready, including after reload/redeploy. A worker chunk already executing may finish its shared word-cache work, but its abandoned chain cannot reserve a selection.

## Validation and limits

See `VALIDATION.md`. No production volume was accessed. Physical iPhone interactions and full browser rendering were not verified in this environment.
