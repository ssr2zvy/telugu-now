# Validation

- `npm run build`: passed (TypeScript, Vite frontend, server bundle, parser asset packaging).
- Python word-cache regression suite: 18 passed. Includes fresh/cached attempt counts, multi-target matches, shortest-word/shortest-five policies, ambiguity rejection, exact compatibility migration and incompatible-cache invalidation.
- Focused TypeScript regression suites: 29 passed. Includes settings page hierarchy, status labels, current-word evidence, worker timeout/restart, persistent cache totals while idle, chain reset/promotion/waiting, recorded-answer locking, reader gestures, and swipes starting over controls.
- Patch apply check against a clean index at `976ae94d9c8e6e37e51364ae44be8fd36bda162c`: passed.
- `git diff --check`: passed.

The reset regression uses temporary SQLite databases, a deterministic parser fixture and the real selection/navigation services. The swipe regression exercises the capture handlers, including control-origin gestures; it is not a physical-device browser test.

No live Fly volume was accessed. No physical iPhone or full browser rendering validation was performed. The build and focused tests are the verified scope.
