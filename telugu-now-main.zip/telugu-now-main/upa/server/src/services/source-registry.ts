import type { DataSource } from '../domain/source';
import { PreparedCorpusDataSource } from '../sources/prepared-corpus/prepared-corpus-data-source';
import { preparedCorpusStore } from '../sources/prepared-corpus/prepared-corpus-store';

const REQUIRED_PREPARED_SOURCE_IDS = [
  'fleurs-te',
  'shrutilipi-te',
  'indicvoices-te',
] as const;

export class SourceRegistry {
  private readonly sources = new Map<string, DataSource>();
  private revision = 0;

  get generation(): string {
    return `${this.revision}:${[...this.sources.values()].map(source => source.generation ?? '').join(':')}`;
  }

  constructor(options: { includePreparedSources?: boolean } = {}) {
    if (options.includePreparedSources === false) return;

    for (const sourceId of REQUIRED_PREPARED_SOURCE_IDS) {
      if (preparedCorpusStore.hasSource(sourceId)) {
        this.register(new PreparedCorpusDataSource(sourceId));
      }
    }
  }

  register(source: DataSource): void {
    if (this.sources.has(source.id)) throw new Error(`Duplicate data source id: ${source.id}`);
    this.sources.set(source.id, source);
    this.revision += 1;
  }

  selectableSources(): DataSource[] {
    return [...this.sources.values()].filter((source) => source.enabled);
  }

  selectableSourceIds(): string[] {
    return this.selectableSources().map((source) => source.id);
  }

  get(sourceId: string): DataSource {
    const source = this.sources.get(sourceId);
    if (!source) throw new Error(`Unknown data source: ${sourceId}`);
    return source;
  }

  assertPreparedSourcesPresent(): void {
    const missing = REQUIRED_PREPARED_SOURCE_IDS.filter((sourceId) => !this.sources.has(sourceId));
    if (missing.length > 0) {
      throw new Error(`CORPUS_NOT_PREPARED:${missing.join(',')}`);
    }
  }

  sourceInfo() {
    return this.selectableSources().map((source) => source.info());
  }

}

export const sourceRegistry = new SourceRegistry();
