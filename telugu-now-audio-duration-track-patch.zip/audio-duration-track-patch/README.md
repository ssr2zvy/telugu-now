# Audio duration track

Small follow-up patch for the grammar branch. Apply after the previously supplied settings ZIPs. This patch changes only `upa/frontend/src/styles/audio-material.css`; it does not overlap the Appearance pages patch.

## Apply

From the repository root:

```sh
git apply --check /path/to/audio-duration-track-patch/changes.patch
git apply /path/to/audio-duration-track-patch/changes.patch
cd upa
npm run build
```

Use either changes.patch or the matching changed-files replacement, not both. Deploy the rebuilt frontend through your normal workflow. Nothing was pushed or deployed.

## Change

Restores the existing full-duration pseudo-element as a stationary 1px line at 28% opacity using the audio control color. It shares the cursor's full travel bounds and sits beneath the existing progress layer. It remains visible before playback, when progress is zero, and supplies the path ahead of the cursor during playback.

The line has pointer-events disabled. No playback, progress, seek, timing, gesture, cursor, recording, or magnifier logic is changed. No component markup or JavaScript is changed.

## Validation

- Frontend production compilation passed.
- Patch whitespace check passed.
- Patch applies cleanly after the preceding Appearance pages patch.
- Physical iPhone/browser interaction was not verified; this change is limited to the decorative CSS layer.
