# iPhone recording and comparison controls

Base: `ssr2zvy/telugu-now`, branch `grammar`, commit `1efe83201dc3a009b1f2a329bc543b11ae135884`.
This branch already contains the consolidated diagnostics and Core 1 shortest-five changes.

## Apply

Run from the repository root after extracting this ZIP:

```sh
git apply --check /path/to/iphone-recording-comparison.patch
git apply /path/to/iphone-recording-comparison.patch
cd upa
npm run build
npm run test:recording-controls
```

The ZIP includes both a unified diff and complete replacement/new files under `changed-files/`. Use one method. The patch was checked against the base commit and its reconstructed files verified byte-for-byte. Build and deploy the frontend and backend together using the existing deployment workflow. This ZIP has not been deployed.

## Recording compatibility

The existing client saved the browser's native recording container and then used Web Audio decoding for playback. The reported iPhone error is consistent with failure in that decode step, but the original device recording was not available to reproduce it directly.

New uploaded recordings are decoded on the server and saved as mono, 24 kHz, 16-bit PCM WAV with exact RIFF/data lengths. This avoids requiring the browser's playback preparation to decode its native MP4/AAC or WebM/Opus recorder output. The client reports the returned recording as WAV. Existing saved native-format recordings are also converted to WAV when requested for playback; their stored original bytes are preserved.

The existing container already installs FFmpeg. Conversion has bounded input size (16 MiB), decoded duration (two minutes, matching the existing player limit), output size, timeout (20 seconds) and concurrent jobs (two). Malformed or overlong recordings fail without replacing the saved answer. The response is checked again after conversion so a late upload cannot overwrite an answer finalized meanwhile. WAV uses more storage than compressed recordings, up to approximately 5.76 MB of sample data for a two-minute recording.

Recorded chunks are scoped to their individual recording session. Recording icons, dimensions, colors, seek behavior, explicit playback and magnifier controls are retained.

## Comparison switch

- The evaluation control appears on comparison pages for both question types.
- It is one actual switch with no visible True/False labels, prompt or instructions. It retains an accessible name for screen readers.
- Each unanswered comparison starts Off (False). Toggling changes only the draft and does not save progress.
- Double-clicking/tapping forward submits the draft, waits for successful persistence, then uses the existing forward navigation. Accessible forward-button activation follows the same behavior.
- A failed save keeps the comparison open for retry. Duplicate forward attempts do not duplicate the save. Saved answers remain locked when revisited.
- The existing subsequent observation page is retained, without the evaluation control. An older unfinished evaluation screen is restored to comparison so it cannot become a dead end.
- The server accepts comparison evaluations and rejects advancing an unanswered comparison without a saved evaluation. Existing recorded progress and True/False semantics are preserved.

## Borderless comparison and final observation

The central divider is removed. Each answer sits on a soft, fading surface using the existing foreground palette, with open space between the two sides. Text/audio positions, sizes and controls remain unchanged.

The page sequence stays **question → comparison (with the switch) → normal observation**. The final page uses the normal observation text/audio presentation, without the evaluation switch or comparison treatment.

## Record-button placement

The recording button is below the entire audio-control area, including the space reserved for an expanded magnifier. A minimum bottom clearance includes the iPhone safe area plus 16 px (at least 24 px total). When necessary, the question audio bar is raised to reserve that space. The existing record-button size, glyph, colors, control gaps and motion behavior are retained. Audio-given keyboard positioning is unchanged.

## Validation

- Production build and TypeScript validation passed.
- `npm run test:recording-controls`: 29 tests passed.
- Borderless comparison update: frontend build and the focused comparison layout regression check passed.
- Real FFmpeg conversion of generated fragmented MP4/AAC and WebM/Opus fixtures to canonical WAV passed, including decoding the resulting WAV again.
- Tests cover malformed/empty/oversized/overlong input, saved response persistence and final-answer locking, comparison-stage progression, switch rendering/default state, and existing audio controls.
- Patch application and all changed file contents verified against the specified branch base.

Physical iPhone microphone capture/playback and touch layout were not tested. A local browser installation attempt failed because the browser download was incomplete, so browser interaction/visual checks were not completed. The tests validate conversion, server behavior, rendering contracts and compilation; they do not establish that the exact device-specific failure is resolved on hardware.
