Reader fixes patch
Base: main 1fe099592ea0a051dd8be37130d464d6ffa95aeb
Apply on your feature branch, then merge to main. Deployment workflow is unchanged.

Apply ONE option from repository root:
- Copy replacement-files/ contents into the repo, preserving paths.
- Or use git apply --check changes.patch, then git apply changes.patch.

Changes:
1. Browser NotAllowedError during automatic playback waits silently for a tap.
   Explicit playback failures and genuine file/preparation errors remain visible.
   Removed obsolete bottom-third instructions and constrained error messages to the viewport.
2. Speed editor dismissal includes the surrounding box, readout and 16px outer padding.
   Slider interaction still adjusts speed. The readout is keyboard accessible.
3. Reverse exploration gesture immediately restores the original observation and resets
   the random draw counter. No history replay or accumulated history storage.
   Existing gesture mapping is preserved: internal up draws, down exits. New visits
   still begin at configured start probabilities. Tap audio and fixed text positions stay.

Validation:
- npm run build passed, including typecheck, frontend and backend.
- Focused suites: 25 passed, 7 failed. All 7 failures also occur on untouched base main
  in audio-controls.test.ts; no additional failures remain after updating the speed
  readout assertion for the new accessible dismiss button.
- git diff --check passed.
- Patch checked against its exact base.
- No physical iPhone/iPad gesture test performed.

Nothing pushed or deployed.
