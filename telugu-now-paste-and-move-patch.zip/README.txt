Telugu-now: keyboard copy/paste, selection repairs and repository moves

Base: main at 0690206109da7ce35542a182e7c2ad4aedf34c8f (0690206).
The previous profile repository patch is already included in this base.
This updated ZIP includes paste, move, explorer navigation and Copy inside the keyboard.
It also includes the selection/cursor/backspace repairs below.
It replaces the earlier paste-and-move ZIP. If that ZIP is already applied, use
replacement-files/ below to update the files; the main-based patch includes both.

APPLY ONE METHOD

A. Copy the contents of replacement-files/ into the repository root, preserving
   the upa/ paths. Include the new KeyboardPasteButton.tsx file.

OR

B. From the repository root:
   git apply --check /path/to/changes.patch
   git apply /path/to/changes.patch

Do not apply both. If later source edits conflict, review them rather than
forcing replacement files over newer code. Commit and use your existing main
branch deployment workflow. Nothing in this ZIP has been pushed or deployed.
No new secrets, volumes, dependencies, or database migration steps are needed.

BEHAVIOR

Selection/cursor repairs:
- Highlight geometry is clipped to non-overlapping CSS line bands instead of
  using oversized font range bounds. The observed Noto Sans Telugu range was
  34px tall while lines were only 33px apart.
- Hit testing chooses the touched line first, then a grapheme within that line.
- Selection handle hitboxes no longer extend into the following text line.
- The cursor retains the touched side of a soft wrap. Backspace retains the
  preceding boundary, and scheduled caret restoration reads the latest
  selection rather than replaying a previous deletion's position.
- Native select events for outdated DOM values are ignored; font-loading
  completion refreshes measurements.
- Cursor and magnifier strokes are 1px, cursor height is capped to font size,
  and visible handle markers are smaller.

- Copy is now inside the keyboard beside Paste, replacing its top-of-screen
  placement. It copies selected text, or all entered text when there is no
  selection, using the existing clipboard logic.
- The shared custom keyboard has an icon-only paste key. This includes audio
  questions, freestyle, repository names and document editing.
- Paste inserts text at the custom cursor or replaces the selected range.
  Documents/freestyle preserve line breaks; single-line answers/names flatten
  line breaks to spaces, matching existing input behavior.
- Empty/non-text clipboard contents leave text unchanged. Denied or unavailable
  clipboard access shows an error icon on the paste key; tapping it retries.
- Clipboard reads occur only on a user click. The browser/OS may require its
  own paste permission prompt; the app does not bypass it. HTTPS is required.
  Reference: https://developer.mozilla.org/en-US/docs/Web/API/Clipboard/readText
- Each file/folder overflow menu now includes a move icon beside rename/delete.
- Move mode browses destination folders. Its bottom-right checkmark commits the
  move. X cancels without moving anything and returns to the original directory.
- Normal folder browsing uses X to close the explorer. The back arrow is removed
  from the explorer; each non-root directory has a '..' parent entry. The root
  directory has no parent entry. The document editor retains its back control.
- Move mode hides files and the folder being moved. Server validation also
  rejects moving a folder into itself/descendants, cross-profile destinations,
  file destinations, duplicate names, stale revisions and excessive depth.
- Moving a folder retains all descendants and document contents; IDs stay the
  same. Existing volume persistence and autosave are unchanged.

VALIDATION

- npm run build passed (TypeScript, frontend and backend).
- 18 focused tests passed, including subtree integrity, root moves, profile
  isolation, collisions, cycles, depth limits, stale updates and draft safety.
- Mobile-size Chromium checks passed using actual clipboard reads: insertion,
  selected-text replacement, multiline handling, empty clipboard, denial/retry,
  create-dialog paste and document paste with autosave.
- Browser move checks passed: cancellation, '..' navigation, root destination,
  folder subtree/file moves and bottom-right checkmark placement.
- Browser regression checks passed with Noto Sans Telugu, Noto Serif Telugu
  and Mandali: non-overlapping highlights, second/third-line selection, repeated
  and rapid backspaces, and cursor dimensions/placement after deletion.
- Inline Copy was additionally checked in a mobile-size browser: correct
  placement beside Paste, full-text/selected-text copying and no top copy button.
  TypeScript and the four reading-tool rendering tests passed after this change.
- Mobile screenshots were inspected. Physical iPhone/iPad testing was not
  available.
- The patch was applied to the exact base in an isolated Git index and every
  output file matched its packaged replacement bytes.

Contents: changes.patch, replacement-files/, manifest.json, README.txt.
