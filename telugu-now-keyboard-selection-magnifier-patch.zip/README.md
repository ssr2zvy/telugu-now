# Custom keyboard caret and selection

Base: ssr2zvy/telugu-now main at cd973e68b64e1ec62c0d0d783b06fa13c3cbed7c.
Apply after the previous keyboard Copy-menu patch (already present in this base).

## Behavior
Applies to the freestyle keyboard and audio-given question keyboard.

- Copy moves to the top right, immediately left of the reader Settings position. In free typing it uses the same corner position; the existing Back button remains.
- Copy copies the selected text, or the whole draft when nothing is selected. It uses the existing icon treatment and brief checkmark feedback.
- Hold the typed text for 500 ms to place a caret and open the magnifier.
- Drag while holding to select letters and words. Drag backward to shrink or reverse the selection. Hold near an edge while dragging to scroll through a long draft and extend selection.
- Release to keep the selection. Drag either selection handle to adjust it. To move just the caret, hold and release without dragging, then drag its handle.
- Backspace deletes the selected range. Typing replaces it. Ordinary typing, free-typing newlines and question submission continue using the existing keyboard.
- Touch caret/selection/magnification are drawn by the app, with Telugu grapheme boundaries. Browser touch-selection menus and handles remain suppressed. Hardware keyboard editing is retained.
- Copy and selection UI disappear when the question keyboard is inactive.

Long-press reading menus on ordinary observations, word views and letter views are unchanged.

## Apply
Use ONE method from the repository root.

Recommended: apply changes.patch. This also removes the obsolete keyboard menu hook.

    git apply --check /path/to/changes.patch
    git apply /path/to/changes.patch

Alternatively, copy replacement-files/ over the repository, preserving paths, and DELETE the file listed in deleted-files.txt:

    upa/frontend/src/observation/useKeyboardCopyMenu.tsx

No dependency, deployment, parser, credential or volume changes. This archive has not been pushed or deployed.

## Validation
- TypeScript typecheck passed.
- Production client build passed.
- 15 focused tests passed (Telugu boundaries, wrapped-line geometry, reading menus and reader gestures).
- Chromium browser interaction checks passed in both actual keyboard components at a mobile viewport with the app's Telugu fonts: touch long press, magnifier, forward/backward selection, caret movement, range handle adjustment, copying the selected text, replacement by virtual typing, deletion, edge autoscrolling, and no unintended reader swipe.
- Screenshots checked for text/selection alignment and magnifier rendering.
- Patch applied successfully to a clean temporary index; resulting files exactly match replacement-files/.

Physical iPhone/iPad Safari was not available. Confirm these same touch gestures there after applying.
