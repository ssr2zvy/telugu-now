# Appearance pages and settings memory

Follow-up patch for the grammar branch of ssr2zvy/telugu-now.

## Required order

1. Apply `telugu-now-next-chain-search-settings-patch.zip` first.
2. Apply this ZIP second. Do not apply both simultaneously to the same checkout.

This patch was verified after applying the preceding ZIP to grammar revision
`976ae94d9c8e6e37e51364ae44be8fd36bda162c`. It contains only the follow-up changes.
The manifest's local prerequisite snapshot is a packaging reference, not a remote commit you need to check out.

From the repository root, using this ZIP's changes.patch:

```sh
git apply --check /path/to/appearance-pages-patch/changes.patch
git apply /path/to/appearance-pages-patch/changes.patch
cd upa
npm run build
```

The patch and `changed-files/` contain the same changes; use one application method, not both.
Deploy the rebuilt frontend and backend together so profile preference parsing retains the new default-color version marker. Nothing has been pushed or deployed.

## Changes

- Appearance opens navigation pages. Background, reading text, letter modifications, audio controls, and settings surfaces each lead to their own subpages.
- Every slider, switch, font choice, position choice, and randomization action is reached through its own page.
- Letter modifications contains Highlight mods, Gradient end color, and Modification lightness.
- Each color page offers presets first and a Color wheel page. Gradient end color defaults to the Icon color preset. There is no separate Automatic option. The native color picker remains device-specific.
- Each data source under Observations opens a separate details page.
- The default reading color is tinted violet (#34304a). Random theme reading colors also avoid neutral black and white extremes. Existing custom colors remain available. The exact legacy default (#171717) migrates to violet when unversioned; it cannot be distinguished from an old deliberate choice of that same value. Choosing it explicitly after this update is preserved.
- X closes settings without resetting its page or back stack. Reopening for the same observation restores the last page, including the selected font, data source, or search attempt. Question/comparison/observation phases share that memory. Opening settings for a different observation or profile starts at the entry page. This memory is local to the running app, not persisted across reloads.
- The explicit settings overview action still returns to the entry page.

## Verification

See VALIDATION.md. Production data and the deployed app were not accessed.
