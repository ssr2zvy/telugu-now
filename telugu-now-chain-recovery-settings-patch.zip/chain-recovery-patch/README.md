# Chain recovery and settings patch

Apply to grammar commit dbf48070b420145eb3dd48a5dabeeb9eec9d30cb (both earlier comparison and settings patches are already merged). This patch includes frontend and backend changes; deploy them together.

```sh
# From the repository root
git apply --check /path/to/changes.patch
git apply /path/to/changes.patch
cd upa
npm run build
node --import tsx --test tests/chain-recovery.test.ts tests/worker-recovery.test.ts tests/parser-settings.test.ts tests/text-comparison.test.ts
```

Alternatively copy changed-files/ into matching repository paths. Do not apply both methods.

## Current

Core progress and matched word remain visible. Chain, Search and Reset are expandable sections. Chain lists saved matched Telugu words in selection order, with the current step indicated, rather than depending on transient worker search patterns. Search shows the active target, words checked, search start time, and saved next selections in queue order with readiness. Further steps are not invented. The old queue navigation icon is assigned to Current. Reset retries selection and audio preparation while preserving history, answers, mastery and selected observations.

## Diagnostics

Four top-level disclosures: Object coverage (including filters and coverage notes), Search and parse (current search, totals, word cache, selected-word evidence and technical details), Cycle history (latest 20 actual chains with their saved words), and Events (including the full-history download). Data Sources moves to Observations alongside Parser and Questions. The full export retains all recorded history, not just the latest 20 chains or 50 events.

## Recovery and Unicode

Chain history lives in the user SQLite database: normally /data/user/users.sqlite under the Fly configuration, unless DATABASE_PATH overrides it. Chains, searches, acquisitions and selected words persist. The in-memory visited/exhausted sets still reset on a process restart; interrupted chains are closed and later selections start a new chain.

The former Current display required runtime parser patterns for modifier targets, producing “Unicode unavailable” after restarts or while the worker was idle. Chain rendering now prefers its actual saved word. Inventory examples can label targets when runtime needles are unavailable, and coverage identifies those as examples rather than claiming they are search needles.

Horizontal swipe and arrow navigation now operate across text-given, audio-given and legacy observation pages, instead of only text-given pages. Back remains available while the current entry is loading when history permits it. Forward still requires a prepared next observation; the patch does not skip an unanswered comparison or invent a next match.

Worker startup and requests have bounded waits. A failure, timeout or explicit reset rejects pending callers and permits a clean restart instead of leaving selection permanently waiting. Default startup timeout is ten minutes; per-request timeout is two minutes. GRAMMAR_STARTUP_TIMEOUT_MS and GRAMMAR_SEARCH_TIMEOUT_MS can override them. Manual reset of an active search restarts the shared parser process; another profile's in-flight search may retry, without loss of its saved data. Existing selected observations are retained. No answers or history are erased.

## Blacklist removal

Blacklist settings, sentence/letter context actions and the image blacklist action are removed from the active interface. Sentence blacklist routes are no longer mounted. Selection, preparation and grapheme lookup no longer use saved sentence exclusions. Existing archived rows are left inert for archive compatibility; no destructive user-database purge is performed.

## Verification

Build and targeted results are in validation.txt. Tests cover persisted Unicode evidence, ordered next selections, profile isolation, restart history, parser timeout/restart handling, hierarchy, progress, disclosures and swipe direction thresholds. Browser/physical-iPhone gesture and animation testing is not available in this environment. The user's live volume was not accessed; fixes address verified code gaps, not a claim to have reproduced the exact production incident.

After deploying, use Observations → Parser → Current → Reset if the old search is still stuck. Open Search to inspect the active target and next prepared selections. A genuinely exhausted corpus search will remain explicitly blocked rather than be mislabeled as loading.
