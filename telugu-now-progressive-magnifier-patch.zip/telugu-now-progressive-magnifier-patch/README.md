# Progressive, coarse audio magnifier — incremental patch 10

Apply after patches 01–09 from telugu-now-ui-patch.zip. This ZIP is an incremental add-on, not a replacement for the earlier cumulative ZIP. No production deployment has been performed.

From your repository root:

```sh
git apply --check /path/to/10-progressive-coarse-magnifier.patch
git apply /path/to/10-progressive-coarse-magnifier.patch
```

If the check fails, reconcile against your newer code rather than forcing it. Final copies of the four affected files are included under files/ for review, with exact before/after hashes in manifest.json.

## Behavior

Window span = min(recording duration, clamp(0.02 × recording duration, 0.25, 2)) seconds. It follows the playback/seek cursor, centered except at clip boundaries. Duration is the player's prepared duration, including any existing silent lead-in.

| Recording duration | Window span |
|---|---|
| 10 seconds | 0.25 seconds |
| 30 seconds | 0.6 seconds |
| 60 seconds | 1.2 seconds |
| 100 seconds or more | 2 seconds |

The display max-pools the existing waveform into 120 buckets across the whole recording, then shows the buckets overlapping the moving window. These bars stretch across the magnifier with 1px gaps, recreating the older coarse silhouette. Boundary buckets can include amplitude just outside the exact window, as in the historical design. Very long recordings can show only one or two bars. High-resolution prepared peaks are retained internally; audio bytes, bar height, gradients, position, and the latest fine-drag speed are unchanged.

## Validation

Four waveform tests pass, TypeScript check passes, and Vite production frontend build passes. Patch applies cleanly to the previous patch09 source; all four resulting file hashes verified. Visual browser/device confirmation is still pending.
