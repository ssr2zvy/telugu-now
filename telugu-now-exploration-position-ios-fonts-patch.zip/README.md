# Exploration position and iPhone/iPad fonts

Base: grammar 3db5d58936aae7ddba5cd80ff5ca446e2256ccbe.
This ZIP contains a patch, replacement files and validation logs. It has not been pushed or deployed.

## Apply
From the repository root, apply changes.patch with git apply --check followed by git apply, or copy the contents of files/ into the repository root, preserving paths. Use one method, not both. No files need deletion. Commit to grammar and deploy through the existing workflow.

## Changes
- Exploration uses the actual observation text element and its existing typography. Each letter, word and accumulated phrase appears where it belongs in the full sentence. No separate fragment sizing, centering or layout.
- Hidden text retains its space, preserving balanced line breaks, glyph size, gradient highlights and the audio anchor. Reversing the sequence and returning to the observation reveals the same layout.
- Hidden components are excluded from copying, accessibility exposure and word/letter hit testing. Source offsets remain intact. Single tap uses the existing snippet audio implementation without an audio bar or autoplay; double tap still opens visible word/letter focus.
- iPhone and iPad use Noto Sans Telugu and Noto Serif Telugu only, including the existing font rotation and settings list. Old NTR settings cannot cause iOS observations to use NTR. Desktop and Android behavior is unchanged.
- Passwords, deployment workflows, profile data and parser logic are untouched.

## Verification
- TypeScript and production frontend/backend build: passed.
- 13 focused font, exploration sequence, render structure, copy and font deck tests: passed.
- 5 focused existing grapheme/hyphen/source-range tests: passed.
- Patch checked and applied to a clean index of the exact base; replacement bytes verified.
- The broader reader-hyphenation test file contains an existing unrelated source-regex test named "reader page resets animation and question controls in a layout effect" that fails on the unmodified base too. It is not included in the 5 passing targeted checks and has not been rewritten.
- Browser visual/device validation was unavailable: Playwright's browser download returned an invalid archive. Verify on iPhone/iPad after deployment: step through a multiline observation forwards/backwards, compare positions, tap snippet audio, double tap a visible letter/word, and confirm the two-font list.
