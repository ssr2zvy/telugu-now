# Continuous gradient swipe patch

Based on grammar commit `59ba72b6cd311e8bbe3554428b13fe6d05caa04e` in ssr2zvy/telugu-now. This base already includes the earlier settings, appearance, duration-track and reader-refinements patches.

## Apply

From the repository root on grammar:

```sh
git apply --check /path/to/gradient-travel-patch/changes.patch
git apply /path/to/gradient-travel-patch/changes.patch
cd upa
npm run build
```

Use changes.patch or the changed-files replacements, not both. No database changes, volume changes or user-progress reset are needed. Nothing has been pushed or deployed.

## Behavior

The background previews horizontal travel while swiping between observations and settles when navigation succeeds. Back retraces the same gradient positions. Canceled swipes and unsuccessful navigation settle back. Keyboard navigation receives the same movement. Question, comparison and final-observation phases of one observation keep the same background position. Vertical audio gestures do not move the gradient.

Server observation-history position determines the committed position. Drag previews stay in memory and do not update progress. Rapid reversals start from the currently painted frame. Reduced-motion preference disables animated travel. Word and letter inspection use the same background position.

Three mirrored repeating SVG gradient layers retain the existing palette, angles, stops and opacity, with small differences in travel speed. Matching tile edges and bounded pattern transforms allow continuous movement without exposed blank edges or a visible reset. This replaces the previous per-observation rotation; it does not generate new colors during navigation.

## Validation

13 focused motion, gesture and navigation tests passed. Production build passed, including TypeScript, frontend, backend and worker packaging. Whitespace and clean-index patch application checks passed; applied files were verified against the packaged replacements. Logs are in validation/.

Physical iPhone interaction and browser visual rendering were not verified. A legacy word-profile source test was also attempted but contains pre-existing expectations for removed context-menu and blacklist functionality; it remains unchanged and is not counted among the passing tests.
