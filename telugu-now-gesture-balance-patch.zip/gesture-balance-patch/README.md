# Gesture balance and evaluation timing

Based on ssr2zvy/telugu-now grammar commit 653df0ac59ffa673d852d4e054e5ecd97abaf007. Includes only changes after the reader-controls-fix patch already applied to this base.

## Apply

From the repository root:

```sh
git apply --check /path/to/gesture-balance-patch/changes.patch
git apply /path/to/gesture-balance-patch/changes.patch
cd upa
npm run build
```

Deploy frontend and backend together: the server comparison-phase navigation gate changes. No database rebuild, migration, volume cleanup or progress reset. Nothing was pushed or deployed. Use either the patch or the supplied changed-file replacements.

## Changes

- Only visible sliders claim horizontal audio gestures; the surrounding audio-bar rectangle no longer blocks navigation. Horizontal audio dragging stays audio-owned even when the pointer leaves the slider. Vertical gestures on sliders transfer to page audio disclosure without gradient travel. Ordinary page and button swipes still work.
- Hidden audio bars are inert and hidden from accessibility navigation; hidden bars and precision-panel descendants cannot receive pointer events. Native panning no longer cancels either reader swipe axis; pinch zoom remains available.
- Comparison pages start with audio hidden. Down reveals the bar; another down opens precision controls. Up reverses these steps. The comparison switch remains visible.
- The record/switch safe-area floor is raised by 24px; existing audio collision avoidance stays in place.
- Moving from comparison into the final observation no longer commits an evaluation. The draft remains editable if you return to comparison. Advancing from the final observation saves the evaluation, then navigates. The switch is not shown on the normal observation, but save errors remain visible. Previously saved evaluations remain locked. Drafts remain in-memory as before; reloading an unsaved draft resets it. A successful save remains final even if the subsequent navigation request fails; retrying navigation does not save twice.

## Validation

Production build and 13 focused gesture, gradient and navigation tests passed. Whitespace and clean-index application checks passed; applied file hashes match replacements. Logs are included. Physical iPhone/browser visual testing and an end-to-end server evaluation-flow test were not performed.
