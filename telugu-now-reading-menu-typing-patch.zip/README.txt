Telugu Now — reading menu and free typing
Base: main at 0ab8df4912e0b3981ec8372d4bec391515e8730e

Changes
- Long-press the reader text/background to open an icon-only Copy / Keyboard menu.
- Copy uses the full observation, focused word, or focused letter respectively.
- Keyboard opens free-form typing with the existing Telugu keyboard and appearance.
- No audio controls or audio playback in the typing screen. Enter inserts a new line.
- Back returns to the same reader view. The draft remains while that view stays mounted;
  it is not submitted as a question answer or saved to the server.
- Long presses do not also play audio. Movement cancels the hold so swipes keep working.
- Desktop right-click opens the same menu. Escape dismisses it.
- Existing audio, record, image and input controls retain their own interactions.

Apply ONE method from the repository root:
1. git apply --check /path/to/changes.patch
   git apply /path/to/changes.patch
OR
2. Copy the CONTENTS of replacement-files/ into the repository root, preserving paths.
   Include the new files. Do not apply both methods.

This patch is based on the current main above, including the previous exploration fixes.
No server, deployment, access-key, parser, or volume changes. No dependencies added.
Nothing has been pushed or deployed by this patch.

Validation
- npm run build: passed (frontend, server, and TypeScript).
- Final npm run typecheck: passed.
- Reader tap and rendered menu/keyboard tests: 11 passed.
- Scope-state regression check: passed.
- DOM interaction harness: long press in all three nested scopes, correct clipboard text,
  movement cancellation, no accidental playback, free typing/newlines, no question
  submission or navigation from typing, Back/draft preservation, Escape and outside
  dismissal all passed.
- The patch applied cleanly to a temporary index of the base commit, and each result
  matched the corresponding replacement file.
- Physical iPhone/iPad testing is still needed; browser installation was unavailable.

Re-run included checks from upa/:
  npm run build
  node --import tsx --test tests/reader-taps.test.ts tests/reading-tools-render.test.ts
  node --import tsx --test --test-name-pattern="reading menus retain" tests/reading-context-menu.test.ts

Other existing assertions in reading-context-menu.test.ts still describe older,
removed features; they are outside this change. Only the obsolete menu assertions
were updated here. A full test-suite pass is not claimed.
