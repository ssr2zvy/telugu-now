import { grammarActive, getCatalog, progress } from '../grammar/service';
import { config } from '../config/config';
import type { ExportResponse } from '../../../shared/contracts';
import { ensureProfileRow, parseObservationAudio } from './profile-service';
import { getProfileSelectionSettings } from './selection-settings-service';
import { selectionEngine } from './selection-engine';
import { sourceRecordService } from './source-record-service';

export class InvalidExportRequestError extends Error {}

export async function generateExport(profileCode: string, count: number): Promise<ExportResponse> {
  if (!Number.isInteger(count) || count <= 0 || count > config.maxExportCount) {
    throw new InvalidExportRequestError(
      `Export count must be an integer from 1 through ${config.maxExportCount}.`,
    );
  }

  ensureProfileRow(profileCode);
  // Immutable snapshot: every selection in this export uses these exact values even if
  // profile settings are changed before this async operation finishes.
  const settings = getProfileSelectionSettings(profileCode);
  // Exports preserve the original weighted selection and never consume Core progress.
  const grammarState: ReturnType<typeof progress> | null = null;
  const entries: ExportResponse['entries'] = [];

  for (let index = 0; index < count; index += 1) {
    const selected = grammarState?getCatalog().choose(profileCode,grammarState):selectionEngine.select(settings);
    const resolved = await sourceRecordService.resolve(profileCode, selected.sourceId, selected.sourceKey);
    entries.push({
      position: index + 1,
      sourceId: selected.sourceId,
      sourceKey: selected.sourceKey,
      text: resolved.text,
      audio: parseObservationAudio(JSON.stringify(resolved.media)),
      diagnostic: {
        ...(grammarState?{grammar:selected.snapshot as Record<string,unknown>}:{}),
        selection: grammarState?null:selected.snapshot as import('../../../shared/contracts').SelectionSnapshot,
        cacheHit: resolved.cacheHit,
        requestStartedAt: resolved.requestStartedAt,
        requestCompletedAt: resolved.requestCompletedAt,
        requestDurationMs: resolved.requestDurationMs,
      },
    });
  }

  return {
    settings: {
      sourceWeights: { ...settings.sourceWeights },
      complexityPercentileTarget: settings.complexityPercentileTarget,
      complexityPercentileSpread: settings.complexityPercentileSpread,
      questionProbability: settings.questionProbability ?? 0.3,
      seenQuestionProbability: settings.seenQuestionProbability ?? 0.75,
      audioGivenQuestionProbability: settings.audioGivenQuestionProbability ?? 0.6,
      complexityReferenceVersion: settings.complexityReferenceVersion,
    },
    entries,
  };
}
