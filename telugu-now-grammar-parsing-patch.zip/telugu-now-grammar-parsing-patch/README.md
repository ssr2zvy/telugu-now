# Telugu-now: corpus parsing and selection modes

Patch base: `ssr2zvy/telugu-now`, branch `grammar`, commit `65fc6ec8aaba44ade73760eb59f35614a4584979`.

This ZIP contains the current implementation, its bundled parser and curriculum graph, and the added integration test. It is a source patch, not a deployed release or a precomputed parsing database.

## Apply

1. Extract this ZIP outside the repository.
2. Start from the base commit above, preserving any local work separately.
3. From the repository root, run `git apply /absolute/path/to/telugu-now-grammar-parsing-patch/changes.patch`.
4. Build and deploy through the repository's normal process (`cd upa`, `npm ci`, `npm run build`). The Containerfile and server packaging script include the Python parser assets.

`files/` also contains the complete contents of every added or changed file, at its repository-relative path. `manifest.json` records the base commit and file hashes. Apply the patch or copy those files; doing both is unnecessary.

## What changes

- **Normal weighting:** existing source weights, complexity controls, and selection logic remain available. Their settings and queue are preserved when changing modes.
- **Parse entire corpus:** Settings starts a server-owned Python worker over every source row in the corpus SQLite. Distinct surface analyses and rule decisions are cached in a separate SQLite. Commits and checkpoints support resuming an interrupted build. Corpus/parser fingerprints prevent resuming incompatible inputs. A completed replacement becomes active only after the worker finishes.
- **Stored evidence:** each source row has its token positions, links to cached analyses, accepted exact curriculum target matches, and Core memberships. Partial or unresolved parses do not automatically qualify as evidence. Vocabulary targets and modifier-chain targets remain distinct.
- **Coverage:** Settings shows distinct source-row totals for Core 1, 2, and 3, plus rows with audio references and target progress. A row can count once in several cores; multiple matches within one core never increase its row count. These totals mean that the row contains a qualifying target, not that every word in the sentence is parsed. Eligible selection also checks current audio availability.
- **Parsing/Core mode:** explicitly enabled after a complete parsing snapshot exists. A random available unmastered target starts a batch; subsequent targets follow the bundled same-core neighbor connections, with the shortest unused eligible whole transcript for each target. Batches contain up to ten observations. A dead end closes the batch early; the next batch starts with another random available unmastered target.
- **Progress:** answers are applied in batch order after the entire batch is answered. Three consecutive True answers master a target; False resets its streak. Mastered targets can still occur as neighbors and can be reset. All required targets in the current core must be mastered before advancing. Missing examples block completion instead of silently removing targets.
- **Duplicates and length:** there is no sentence minimum word count. Sentence text, normalized for Unicode and whitespace, cannot repeat within a profile's core. The same sentence may be used again in a later core. Multiple matching words do not give a sentence extra queue entries or extra credit.
- **Full random mode:** selects uniformly among the app's indexed audio observations without source-weight or complexity-weight bias. It has its own parked queue and does not advance Core progress.
- **Questions:** newly selected observations in every mode are questions. The existing question-type adjustment curve is reused. True/False answers and display history are stored independently of selection weights.
- **Switching:** selecting one special mode turns off the other. Turning it off restores normal weighting and its queue. Existing history, source settings, and old grammar progress are retained. The earlier global GI activation endpoints are retired in favor of the Settings mode controls.

## Runtime and use

Parsing snapshots and resumable builds are written under `corpus/parsing/` in the app's configured data directory, on the existing volume. The worker reads the corpus SQLite; it does not rewrite it or upload a new database to Tigris. Profile mode, progress, pending batches, and parked queues are stored in the existing user database through additive tables.

The whole-corpus build retains the branch's existing operator gate: configure `GRAMMAR_MIGRATION_TOKEN` and enter it in Settings when starting the parse. Viewing statistics and changing a profile's selection mode do not require that operator token. The build runs independently of the browser page. When it finishes, turn on Parsing mode in Settings. Python 3 must be available in the runtime; the repository's container already supplies it.

No generated corpus database, audio files, credentials, node_modules, or runtime caches are included. A corpus build is deliberately not capped at the sample size. Its actual runtime and space requirements depend on total rows, distinct words, and stored evidence.

## Work completed before packaging

- Type checking passed before the final integration-test file was added.
- A real parser run completed on the repository's 300-row sample: 3,298 accepted word occurrences and 1,667 distinct words. Core row counts were 210 / 131 / 66; these are sample counts, not production-corpus coverage.
- The new integration test covers mode queue separation, same-core duplicate exclusion, cross-core reuse, ordered batch updates, progression, random selection, and API guards. Its attempted launch was blocked by the environment's Unix-socket restriction in the `tsx` runner before the test body ran. It is included as source, without a passing-test claim.
- No additional validation, final build, deployment, or production-scale benchmark was performed after the request to package immediately.

The parser and graph are bundled from the latest supplied productive-parser packet used during this work: 1,275 selectable targets (792 vocabulary targets and 483 modifier chains), with 3,362 same-core connections. Per-core inventories are 157/95, 305/235, and 330/153 vocabulary/chain targets. This patch preserves that inventory; it does not assert that every English gloss from the discussion has a distinct covered Telugu target.
