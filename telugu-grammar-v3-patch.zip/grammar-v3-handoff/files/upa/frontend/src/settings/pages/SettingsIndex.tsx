import {
  t,
} from '../language';
import type {
  SettingsPage,
  UiLanguage,
} from '../types';
import { visibleSettingsEntries, settingsPageIcons, settingsPageLabel } from '../navigation';
import { ChevronRight } from 'lucide-react';
import type { ProfileStateResponse } from '../../../../shared/contracts';
import { useAppearance } from '../../appearance';
interface SettingsIndexProps {
  language: UiLanguage;
  state: ProfileStateResponse;
  page: SettingsPage;
  resetting: boolean;
  resetError: boolean;
  onNavigate:
    (
      page:
        Exclude<
          SettingsPage,
          'index'
        >,
    ) => void;
  onResetQueue: () => void;
}
export function SettingsIndex({
  language,
  state,
  page: currentPage,
  resetting,
  resetError,
  onNavigate,
  onResetQueue,
}: SettingsIndexProps) {
  const { appearance } = useAppearance();
  const entries = visibleSettingsEntries(currentPage, state.grammarMigrationAvailable ?? false);
  const summaries: Partial<Record<SettingsPage, string>> = currentPage === 'index' ? {
    observations: state.grammarActive ? (language === 'en' ? 'Grammar progression · batches of 10' : 'వ్యాకరణ పురోగతి · పది ప్రశ్నల సమూహాలు') : (language === 'en' ? 'Grammar selection awaits activation' : 'వ్యాకరణ ఎంపిక ఇంకా ప్రారంభం కాలేదు'),
    external: 'EPUB · HTML · App Archive',
    diagnostic: state.currentObservation
      ? `${language === 'en' ? 'Acquisition' : 'సేకరణ'} ${state.currentObservation.diagnostic.acquisitionNumber}`
      : t(language, 'unavailable'),
    display: `${state.audioSettings.playbackRate}x · ${appearance.fonts.length} ${language === 'en' ? 'fonts' : 'ఫాంట్లు'}`,
    eons: language === 'en' ? 'Named periods of use' : 'పేరు పెట్టిన వినియోగ కాలాలు',
    controlsGuide: language === 'en' ? 'Reading, questions, audio, and navigation' : 'చదవడం, ప్రశ్నలు, ఆడియో మరియు నావిగేషన్',
    about: language === 'en' ? 'Build and deployment information' : 'బిల్డ్ మరియు అమలు సమాచారం',
    reset: `${state.queue.unseenCount} ${language === 'en' ? 'queued' : 'వరుసలో'}`,
  } : {};
  return (
    <div className="settings-index-page">
      <nav
        className="settings-index"
        aria-label={
          t(
            language,
            'settings',
          )
        }
      >
        {entries.map(
          (page) => {
            const Icon = settingsPageIcons[page];
            return (
            <button
              key={page}
              type="button"
              onClick={() =>
                onNavigate(page as Exclude<SettingsPage, 'index'>)
              }
            >
              <Icon className="settings-entry-icon" aria-hidden="true" />
              <span className="settings-entry-text">
                <span className="settings-entry-label">{settingsPageLabel(page, language)}</span>
                {summaries[page] && <span className="settings-entry-meta">
                  {page === 'display' && <span className="settings-palette-preview" aria-hidden="true" />}
                  <span>{summaries[page]}</span>
                </span>}
              </span>
              <ChevronRight className="settings-entry-chevron" aria-hidden="true" />
            </button>
            );
          },
        )}
      </nav>
      {currentPage === 'reset' && <div className="settings-reset-queue">
        <p className="settings-reset-queue-description">
          {state.grammarActive
            ? (language === 'en' ? 'Retry preparation of the current question batch.' : 'ప్రస్తుత ప్రశ్నల సమూహాన్ని మళ్లీ సిద్ధం చేయండి.')
            : t(language, 'resetQueueDescription')}
        </p>
        <p className="settings-reset-queue-description">
          {state.grammarActive ? (language === 'en' ? 'Your selected targets, answers, progress and history stay unchanged. This does not draw a new batch.' : 'ఎంచుకున్న లక్ష్యాలు, సమాధానాలు, పురోగతి మరియు చరిత్ర మారవు. కొత్త సమూహాన్ని ఎంచుకోదు.') : language === 'en' ? 'Your current observation and history stay unchanged. Unseen observations are replaced using your current sampling settings.' : 'ప్రస్తుత పరిశీలన మరియు చరిత్ర మారవు. చూడని పరిశీలనలు ప్రస్తుత ఎంపిక సెట్టింగులతో భర్తీ అవుతాయి.'}
        </p>
        <button
          className="secondary-action"
          type="button"
          disabled={resetting}
          onClick={onResetQueue}
        >
          {resetting
            ? t(
                language,
                'resettingQueue',
              )
            : t(
                language,
                'resetQueue',
              )}
        </button>
        {resetError ? (
          <div className="settings-error">
            {t(
              language,
              'resetQueueError',
            )}
          </div>
        ) : null}
      </div>}
    </div>
  );
}
