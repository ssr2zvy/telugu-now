# Grammatical component policy v3, Settings and parser diagnostics

Apply this patch to `ssr2zvy/telugu-now`, branch `copilot/update-repo-with-zip`, reviewed at commit `83be21e85f99d7c79e53571fee871ed1716c53df`. It updates the existing grammar implementation; it is not a replacement repository. No GitHub branch or commit was changed to produce this package.

## Required behavior

| Form | Category | Complete progression unit |
| --- | ---: | --- |
| Bare core grammar base G | 1 | G |
| Vocabulary V + modifier A | 1 | A |
| Vocabulary W + modifier A | 1 | Same A unit as above |
| Vocabulary V + A + B | 2 | A → B |
| Vocabulary W + A + B | 2 | Same A → B unit as above |
| Core grammar base G + A | 2 | G → A |
| Core grammar base H + A | 2 | H → A, distinct from G → A |
| Core grammar base G + A + B | 3 | G → A → B |
| Bare non-core vocabulary | None | No grammar progression target |

Each core base and each modifier contributes one component; vocabulary bases contribute zero and never appear in progression IDs. Complete component order, length and nesting signature define a unit. Canonical parser IDs combine verified Unicode variants; this is not raw-Unicode-string matching. Surface text and lexical parser evidence remain available for auditing, but vocabulary base identity does not split progress.

Only the selected complete unit receives a result. A successful G → A → B observation does not also increment G, A or A → B. A → B and C → B remain separate units. Bare G is also distinct from modified G. The current parser reports linear nesting; the identity retains its signature for future attachment distinctions.

The Zipf reversal equation, uniform selection within a category, length weighting, three-consecutive-True streaks, regression rule, final-distribution latch, profile isolation and frozen ten-question batches are unchanged. Only the grammatical inventory/categories and their audit metadata change.

## Apply the source changes

This package supersedes the previous v3 patch ZIP. Use exactly one route:

- Original reviewed branch with no v3 patch applied: use `grammar-v3.patch` (all v3 and Settings changes).
- Previous v3 patch already applied: use `after-v3-settings.patch` (only the new Settings/diagnostics changes).
- Manual reconciliation: use the complete replacement files under `files/` and the before/after manifests.

Do not apply both diffs to the same checkout. The incremental patch assumes the exact previously delivered v3 files. Both diffs have been applied to their respective baseline files and verified.

### Preferred: unified diff

From the repository root, with this package unpacked elsewhere:

```sh
git apply --check /absolute/path/to/grammar-v3-handoff/grammar-v3.patch
git apply /absolute/path/to/grammar-v3-handoff/grammar-v3.patch
git diff --stat
git diff --check
```

For an already-patched v3 checkout, substitute `after-v3-settings.patch` in the commands above. `after-v3-manifest.json` lists its expected base hashes.

If the check fails because the branch has advanced, reconcile the listed files with the current branch; do not overwrite newer changes blindly. The patch is based on the previously verified ZIP's code, which exactly matched the reviewed branch. The branch's unrelated SQLite runtime-file changes and uploaded ZIP deletion are not touched.

### Alternative: complete files

Copy each file under `files/` to the matching repository-relative path. `manifest.json` identifies all included paths and their before/after SHA-256 hashes. Do not replace the repository directory or delete paths absent from this package. It intentionally contains no `data/`, SQLite files, credentials, dependencies or generated build outputs.

## Settings and diagnostics additions

- Settings → Observations contains Diagnostic, Data Sources, Blacklist and Reset Queue.
- Settings → External contains separate EPUB Export, HTML Export, App Archive Export and App Archive Import pages. Export format is selected by the page; no format chooser is needed.
- No user-facing question percentage, complexity target/spread or source-weight controls remain in either navigation path. The current branch had no Frequency Export implementation to remove. Display/playback, appearance, image settings, eons, controls guide and app version remain.
- Diagnostic → Parser shows the catalog's parser/adapter/schema versions, dictionary identity, actual search limits, rule fingerprint, corpus counts and exclusion reasons. Selected-word details show parser confidence/status, normalization, canonical analysis and progression target evidence.
- All 15 parser/rule/dictionary files and the parser's initialization/enforcement logic remain unchanged. The adapter has one new reporting helper. Recognition and progression eligibility are distinct; no whole-corpus accuracy claim is made.
- Read-only `/api/profiles/:code/grammar/diagnostics` remains available after the temporary worker is disabled. Old catalogs/observations missing new metadata show that information as unavailable rather than guessing it.
- Reset Queue keeps the existing grammar-mode semantics: retry preparation, preserving batch targets, answers and progress. It does not reshuffle a partially answered batch.
- App Archive Import/Export retains existing selected-observation/audio and browser-local archive behavior. This is not a new whole-app/server backup implementation.
- The grammar curve reverses with progress. The separate sentence-length weighting stays at 1/L²; both formulas are unchanged.

Already-active v3 catalogs are compatible with the Settings-only patch, without progress reset. Additional catalog metadata appears after a future supported rebuild; new questions acquire parser snapshots immediately. If v2 is active, follow the warning below before applying the combined patch.

## Where the changes are

- `progression_targets.py`: typed canonical component IDs (`UNIT:v3`), category counting and vocabulary-base exclusion; core bases retained in all their units.
- `build_grammar.py`: correct target `base_id` storage and fingerprinted progression policy. No corpus schema/data rewrite.
- `store.ts`: reject incompatible catalogs and include core base/components in selection snapshots.
- `SettingsView.tsx`: expose the retained core base and complete components in diagnostics.
- Tests: mapper/catalog behavior, real parser/category agreement, old-policy rejection and existing selection/update regressions.
- Existing migration/validation docs and change manifest: updated semantics and deployment constraints.

## Derived database and deployment

This is a pre-activation correction. Deploy it before switching profiles to the old v2 grammar inventory. Build a fresh derived catalog through the existing temporary Grammar Migration settings page, then activate it. The corpus stays unchanged; the worker performs the existing derived-database upload to Tigris and local-volume publication.

Catalogs now declare `grammatical-components-v3`; their identities include the hash of `progression_targets.py`. A prior v2 checkpoint cannot resume under v3. If the menu first reports a different corpus/parser/policy, click Build/Resume again: the existing worker starts a new staging file after that mismatch. A v2 catalog that was already marked ready must also be rebuilt. Runtime loading and activation reject it.

**If v2 grammar selection is already active, do not deploy this patch directly.** The startup loader will reject that active inventory. Keep the current deployment and implement an explicit catalog/progress migration first; copying streak arrays by index would attach results to different units. This package does not discard user progress, alter the activation flag or migrate existing in-flight grammar batches. Legacy (non-grammar) selection remains available until the usual first activation.

Do not remove the temporary worker on this deployment if the v3 catalog still needs building. After successful v3 activation, the previously documented worker-disable procedure still applies.

## Verification

From `upa/`:

```sh
npm ci
npm run build
node --import tsx --test tests/grammar-*.test.ts tests/appearance.test.ts tests/eons-ui.test.ts
node --import tsx --test --test-name-pattern='Settings routes import|Settings export uses' tests/repository-contract.test.ts
```

Executed for this patch: production build passed; 35 focused Node tests passed, including seven Python behavioral cases. Rendered-component tests cover both navigation paths and direct export pages; metadata endpoint tests cover pre-build, ready and active catalogs. The real-parser migration test confirms `మంచానికి` produces a dative-only category-1 unit and `చేశాను` retains its core base in category 3. Test publication uses a mocked Tigris client. Logs are included under `validation/`. No live deployment or browser smoke test was performed. The final diff was applied to clean baseline files and checked against every supplied replacement-file hash.
