# Automatic text/audio reversal within each grammar category

The fourth patch replaces the fixed text/audio split **in grammar mode** with a second, category-local reversing Zipf curve. The category/target selection curve itself and all progression rules remain unchanged. This automatic rule supersedes restoring a manual text/audio slider for grammar mode.

## The boundary

Let `x` be the existing grammar progression position. At `x = 0`, category 1 has the initial maximum probability. At `x = 1`, category 2 has that same maximum; at `x = 2`, category 3 does, and so on. These are exactly the reset boundaries requested.

The category index is `floor(x)`, not the category of the word randomly selected for an earlier-category review. The category-local phase is:

```
f = x - floor(x)
```

The last category and completed state are handled explicitly so final completion does not reset to a nonexistent next category. Categories are the inventory's ordered nonempty GI levels. Diagnostics preserve both the progression category index and its actual GI level.

## Formula

Use the same `1/r` Zipf family as the existing grammar curve, with two ranks:

```
weights = [1, 1/2]
initial probabilities = [text: 2/3, audio: 1/3]
reversed probabilities = [text: 1/3, audio: 2/3]

P(text | f)  = (1-f) * (2/3) + f * (1/3) = (2-f)/3
P(audio | f) = 1 - P(text | f)           = (1+f)/3
```

This uses normalized weights, so the probabilities sum to one. The endpoints come from Zipf's two ranks rather than arbitrary percentage cutoffs.

| Grammar progression position | Local phase | Text-given | Audio-given |
|---|---:|---:|---:|
| 0 — category 1 starts | 0% | 66.67% | 33.33% |
| 0.25 | 25% | 58.33% | 41.67% |
| 0.50 | 50% | 50.00% | 50.00% |
| 0.75 | 75% | 41.67% | 58.33% |
| Approaching 1 from below | Approaching 100% | Approaching 33.33% | Approaching 66.67% |
| 1 — category 2 takes the original peak | Reset to 0% | 66.67% | 33.33% |
| 1.50 | 50% | 50.00% | 50.00% |
| 2 — category 3 takes the original peak | Reset to 0% | 66.67% | 33.33% |
| Final completion | Held at 100% | 33.33% | 66.67% |

The discontinuity at a category boundary is intentional. The prior category approaches the audio-heavy endpoint and the next category starts text-heavy immediately. Random selection does not guarantee an exact ratio within any single ten-question batch.

## Integration and progress

- `GrammarCatalog.choose` calculates and samples question type from the same frozen progression state used for target selection. The queue uses that exact selected mode instead of drawing again or consulting the legacy fixed percentage.
- All ten questions use their batch's saved progression position. Results remain applied after the ten answers, in the existing order. The next batch uses the resulting position and local phase.
- There is no second streak counter or independent progression clock. Existing three-consecutive-True requirements and False penalties drive both curves through `position`.
- Within-category regression moves the mix back toward text. If regression crosses a category boundary, the mix is recomputed from the fractional position in the returned category. That can be near its audio-heavy end; there is no special override.
- Completion remains latched. The grammar curve holds its final distribution and the question-type curve holds its final audio-heavy endpoint, even during later review failures.
- A short category can complete entirely within one batch. In that case the displayed batch probabilities can jump over intermediate phases or cross a reset without a visibly audio-heavy batch. This preserves the requested ten-question update contract; it does not introduce hidden per-answer reselection.

## Audit data and Settings

Every new grammar selection stores `questionType` inside its existing JSON snapshot:

- policy version: `category-local-reversing-zipf-v1`;
- progression position, category index, category count and actual GI level;
- phase and completion state;
- both probabilities;
- random draw in `[0,1)`;
- selected mode and selected-mode probability.

`route.questionMode` records the chosen mode's probability. `routeProbability` now includes that factor multiplied by the existing category/target/length/observation/token route. It remains the probability of that recorded selection path, not a marginal probability summed across all possible routes or keyboard choices.

Settings → Observations → Diagnostic → Questions shows this saved evidence. Historical selections without these fields display “curve not recorded”; they are not assigned today's probabilities retroactively.

## Deployment compatibility

No SQLite schema, parser inventory, target identity or Tigris recalculation is needed. No existing progress is reset. This patch changes the application backend, so deploy the updated backend along with the frontend. It does not perform deployment itself.

Already-generated questions retain their recorded mode. Newly generated grammar questions, including replacement acquisitions, use the new policy and store it in their snapshots. Replacement questions continue to use their batch's frozen progression state. Legacy non-grammar selection continues to use its saved fixed settings.
