# Patch 09: icon feedback, comparison controls, magnifier

## Settings

The page and rail no longer add their own surface tint over the app theme. Navigation hit areas remain transparent at rest, hover, press, touch-press and selected states. Explicit higher-specificity rules defeat the shared gray touch-press wash and selected-parent highlighting. Icons keep the case-study-1 SVG gradient with saturation/contrast/opacity feedback on the symbol itself. The page does not add a backing shape or glow panel. Keyboard-only focus outlines remain for navigation accessibility. Existing Settings routes and controls are unchanged.

The nested desktop menu has a transparent scrim. Covered content is hidden while the menu is open to avoid text overlap without adding a gray panel. Closing the menu restores it. Positions and hit areas remain unchanged.

## Comparison

The comparison page now uses the existing ReaderTaps recognizer for mouse and touch. A center-third double tap toggles the associated controls of the answer side tapped. Outer thirds still navigate back/forward. A single tap plays/pauses that answer; a recognized double does not also play/pause. Changing observations/unmounting cancels pending taps. Buttons and audio sliders retain their own gestures and are excluded from page navigation. Holding/pressing the audio scrubber opens the magnifier, and its keyboard trigger remains available. Bookmark, playback, speed and loop controls use the existing audio component.

## Magnifier

The visible window is fixed to 0.5 seconds, shortened only for a clip shorter than that. It stays inside clip bounds at either end. Fine dragging changes from 1 ms/pixel to 1.5 ms/pixel (50% faster); it remains independent of total clip length. Fine keyboard seeking uses the same sensitivity. Bar width, visual gradient and main-bar seeking remain unchanged.

## Validation and deployment

17 audio/window/gesture tests passed; TypeScript and the frontend production build passed. Patch application and file hashes were checked. No browser/device visual verification has been completed; confirm hover/touch feedback and comparison gestures on the target devices before deployment.

The GitHub connector could not refresh the branch during this task (request metadata error). This package targets the previously reviewed grammar baseline, with original unchanged UI files recovered from the earlier repository archive. The apply helper checks source hashes and refuses mismatches rather than overwriting newer changes.

No doctor code, deployment configuration, Tigris write, database change, or grammar activation behavior is added by patch 09. Earlier patches remain included in the combined package.
