# Coordinated navigation feedback

The parent session's 1500ms event lifetime was independent of the arrow CSS animation, which could restart when loading ended. The reader now retains the newest navigation event locally until its arrow finishes. Parent event expiry does not release the corner. The arrow remains visible while the request or presentation loading is pending. Once ready, a fresh keyed arrow runs its 1500ms animation. Its own animationend releases the corner and the phase icon mounts and fades in.

Each navigation and readiness change increments a generation. Completion callbacks from previous generations cannot finish the current sequence. The new state is reconciled before children commit. New profile ownership clears the previous sequence. The phase icon and navigation arrow use the same active state and never mount together.

A generation-checked fallback at 1700ms after readiness handles reduced-motion styles, suppressed animations, and missing animationend events. Normal operation uses animationend. No navigation API, corpus, progression, styles, icon paint or geometry changes. The parent session timer remains compatible with other consumers, but no longer determines reader visibility.

Tests cover parent expiry during loading, 30 rapid navigation events, stale completion rejection, readiness interruption, no replay after completion, and profile changes. Browser/device validation is pending. Before deployment check fast next/back through question/comparison/observation phases, slow loading, and reduced motion.
