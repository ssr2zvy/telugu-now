# Material rules

The shared palette comes from the existing `appearanceAudioGlass` family. The original audio gradient calculation is preserved. Ordinary playback receives no new animated gradient.

| Element/state | Rule |
|---|---|
| Resting icon | Gradient on the glyph itself; opacity .72; subtle edge |
| Hover | Same palette, opacity 1, saturation 1.16 and contrast 1.08 |
| Press | Same palette, opacity 1, saturation 1.2 and contrast 1.14 |
| Selected audio option | Persistent .9 opacity plus existing filled shape |
| Focus | Existing keyboard focus indicator retained |
| Reduced motion | Material transitions disabled |
| Main audio cursor | Same 11px circle and location; soft highlight and opposite inner edge |
| Main scrubber baseline | Removed with `content: none` on `.audio-scrubber::before` |
| Progress / magnifier window | Existing gradients remain |
| Recording | Existing moving gradient and timeline behavior remain |
| Magnifier | 1 second, clamped to endpoints; approximately 4px bars, 2px gaps |

The waveform cache now samples 160 peak bins per second instead of 120 bins for an entire recording. It max-pools the real peaks into the available display width. Audio samples, WAV encoding, normalization, silence padding, duration, bookmark coordinates and precision-seek mathematics are not changed.

Keypad digits and actions use the same material. The login has no input, textarea or contenteditable element: digits are buttons. Hardware digits, caret movement, backspace, delete and paste still work. Leading zeros are preserved. Three digits still trigger the existing login immediately.

The evaluation selector is a two-option radio group styled as a switch. It begins unanswered. Either choice sends exactly one Boolean to the existing API, disables while saving and after success, and becomes available again on error. It retains the existing bottom anchor; it does not move the audio player. Verify their combined layout in the real application.

No color-only distinction is needed to understand the answer: the controls read “False” and “True,” show a selected state and report saved status. Incidental tokens, grammar progression and target accounting are unaffected. Question type is now chosen automatically by patch 04; see `QUESTION-TYPE-CURVE.md`.
