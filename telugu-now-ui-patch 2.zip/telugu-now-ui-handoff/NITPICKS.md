# Original nitpick audit

“Implemented” means present in this patch; browser/device verification is separate.

| Original item | Disposition |
|---|---|
| 1, 2, 10: hover boxes behind menu/back icons | Implemented: transparent button backgrounds; emphasis on the icon |
| 3: initial speech clipped | Recording feedback starts on MediaRecorder's start event; visible “Preparing microphone…”/“Recording” state. Speech before capture starts cannot be recovered. Real microphone timing still needs a phone check. |
| 4: alignment integration | Already present: word/letter APIs, alignment service and client calls. Preserved. |
| 5: comparison swipe leaves audio half visible | Existing comparison guard in `useReaderScroll` integration is preserved. Not claimed reproduced or newly fixed. Device regression check required. |
| 6: sampling number should become range bar | Obsolete under the grammar selection replacement; no old selection controls restored. |
| 7: magnifier bars too thin | Implemented: one-second window, consistent bar widths, denser actual waveform data. |
| 8: question mark appears before navigation finishes | Phase indicator is not mounted while navigation feedback is active; fades in afterward. |
| 9: indicator absent on ordinary observations | Implemented for ordinary nonempty text/audio observations too. |
| 11: typed-answer font fixed | Implemented: inherits the current observation font. |
| 12: mobile keyboard font/spacing feels off | Existing geometry retained. Needs an actual device example; not claimed fixed. |
| 13: modifier-color “islands” | Needs an exact word, font and screenshot. Glyph segmentation/parser rules are not guessed or modified. |
| 14: copy/blacklist feedback | Word-menu success appears only after the operation succeeds; failures remain retryable. Image copy also reports success. Image blacklist already visibly removes the image. |
| 15: corner icon color | Uses shared audio palette/material. |
| 16: typed-answer scroll | Existing scrolling retained; thin scroll affordance and vertical touch-action added. |
| 17: copy on word page | Existing action retained; async results propagate. Reader word menu now copies its selected word rather than the entire transcript. |
| 18: image double-click unreliable | Uses the existing ReaderTaps timing mechanism for mouse/touch clicks; excludes controls, dialogs and menu actions; cancels pending taps on pane/index changes. Real touch-device verification pending. |

Additional approved changes: custom login keypad, True/False switch-style control, Settings material refresh, refined comparison divider and removal of the main audio baseline while preserving the gradient.
