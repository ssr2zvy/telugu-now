# Verified attachment evidence and overlapping analyses

## What changed

The historical verb supplements contain noun forms and inflected words. Their membership is now candidate evidence, not sufficient validation of verb POS. The EndPeelParser production analysis separates unsupported candidates into diagnostic_analyses. Registered core bases remain trusted. Dictionary verb receivers need entries in verified_lexical_types.json with explicit permitted stem fields. Unverified nominal fragments also cannot bootstrap a verbal chain through a noun-to-verb modifier. Missing or uncertain spelling-normalization evidence is excluded from the verified set.

The initial reviewed registry contains noun పిలుపు and the infinitive receiver పిలవ, with only its form/infinitive stem verified. It is deliberately small. Expand it with reviewed POS and actual stem mappings, not suffix guesses or the existing candidate supplement files. Core verbs continue using the existing grammar's stem tables. This is not full Telugu POS coverage.

Both ordinary analysis and compound candidate search run even after a dictionary/ordinary hit. A narrowly registered -ను + ఇ- junction reconstructs both components and verifies them. It recognizes పిలుపును + ఇచ్చారు. The accusative -ను receiver must be independently reviewed as nominal; merely resembling the ending is insufficient. Other older transparent compound guesses are retained as diagnostic candidates until their component structure is verified. Search remains bounded by the parser's existing depth/state limits; maximum score means maximum among the verified analyses found.

Verified alternatives are retained, overlap is flagged, and selection uses highest verified GI. Unsupported readings cannot raise that score. The adapter preserves full verified and diagnostic analyses in parse_json; standalone selection exports add corresponding JSON columns. Parser/adapter version and attachment policy are exposed in existing parser diagnostics.

## Results

| Word | GI | Result | Progression eligibility |
|---|---:|---|---|
| పిలుపునిచ్చారు | 4 | పిలుపును + ఇచ్చారు; no accepted permission reading | Excluded: unresolved second/third-person agreement targets |
| పిలవనిచ్చారు | 3 | Verified infinitive + permission + past + agreement | Excluded: unresolved second/third-person agreement targets |
| చేశాను | 3 | Existing registered verb chain | Eligible |
| మంచానికి | 1 | Existing nominal/dative chain | Eligible |

The compound GI counts the accusative, the core giving verb, past, and agreement. Full component parses are recorded. It does not credit a guessed permission target. Existing progression stores linear targets; joined compounds also remain excluded from hard targets until structured compound target export is supported. Retaining an interpretation and its GI does not mean silently assigning an ambiguous target to a learner.

## Integration and rebuild

The production path is build_grammar.py → parser_adapter.py → EndPeelParser; these changes apply there and to selection_export.py. The lower-level Engine remains a grammar generation/search mechanism; consumers should use the verified EndPeelParser/adapter output for progression.

Rebuild the derived grammar SQLite using the existing background worker and activate it through the existing settings flow. Existing rows are cached and will not be reinterpreted simply by restarting the app. Parser/adapter fingerprints change, so an old staged output cannot be resumed as this new parser; use a fresh derived output through the current rebuild flow. Source corpus SQLite is unchanged. No build, upload, activation or deployment has been performed by this ZIP.

Expect a possible drop in eligible dictionary-verb targets until more stems are reviewed. No full-corpus coverage claim is made. Existing registered-core behavior and nominal cases are covered by regression tests.

## Validation

Nine new tests pass, including real SQLite build with the parser (original corpus bytes unchanged, GI/overlap diagnostics persisted, wrong targets absent). Seven existing progression-policy tests pass. Engine self-tests pass. Ordered/combined/parser-only application is verified against the pinned repository source, including SHA hashes. Earlier UI/browser verification limitations remain.
