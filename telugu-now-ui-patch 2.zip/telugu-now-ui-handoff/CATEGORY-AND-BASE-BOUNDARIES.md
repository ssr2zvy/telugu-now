# Continued base analysis and Category page

## Parser behavior

A dictionary hit stays a candidate instead of short-circuiting end-peeling. All registered compatible endings remain searchable within depth/state limits. For a dictionary base used under an outer modifier, the parser independently checks whether that base has a deeper verified decomposition. If so, the shortcut analysis is diagnostic-only: the complete combined chain must be licensed by the grammar rather than skipping inner receiver restrictions. Strong partial suffix candidates and incomplete inner searches likewise mark the boundary unresolved. Weak particle/poetic-ending guesses remain diagnostic evidence and alone do not invalidate an ordinary base.

This fixes progression eligibility for శ్రీకాకుళంలోని: the shortcut శ్రీకాకుళంలో + accusative ని is excluded because శ్రీకాకుళంలో has a deeper శ్రీకాకుళం + locative లో analysis. The unsupported లోని interpretation is not fabricated, so the word remains out of progression until a valid complete rule is provided. Deeper and partial evidence is stored under base_boundary_checks and diagnostic_analyses in parse_json. Existing valid examples చేశాను and మంచానికి remain eligible in regression tests.

The change is general across registered endings; it does not guarantee complete Telugu coverage. Search limits still apply and a dictionary may contain legitimate lexicalized forms that warrant explicit disambiguation. No full-corpus coverage measurement has been performed.

## Settings UI

Path: Settings → Observations → Category. Read-only GET /api/profiles/:code/grammar/category uses the existing profile validation middleware. It reads the active catalog and profile state, prioritizing an open batch's frozen state. It does not advance progression or draw a question. Missing/inactive catalogs show an activation message. Errors and manual refresh are supported.

The responsive SVG uses the same probabilities() function as the scheduler. It displays every available grammar level, including gaps in numeric levels. The initial curve is dashed; the current curve is solid. Per-category shading distinguishes fully involved and partially involved reversal regions. Shading is explicitly not a claim of target mastery. Completion holds the fully reversed distribution. A numeric table lists all probabilities and target counts, and an accessible SVG label describes the figure.

Core bases and single-modifier targets are drawn from the active corpus's eligible inventory, not all theoretical rules. Their canonical forms, up to three observed examples, and 0–3 streaks are listed. New derived catalogs store grammar_labels from the actual parser's object definitions. Older catalogs can still display the curve, IDs and examples; the page explicitly indicates missing form labels instead of inventing them.

The page uses English explanatory text; its navigation label supports the existing English/Telugu settings language. All earlier controls remain accessible.

## Rebuild and validation

Deploying the UI makes the curve page available for the current active catalog. Parser changes and canonical form-label metadata require a fresh derived grammar build, followed by the application's appropriate activation/inventory-migration procedure. Do not mix old progress with a different target inventory. Source corpus data and progression equations are unchanged. No live upload, activation or migration has been performed.

Tests cover scheduler equality at integer/fractional positions, normalization, completion, one-category inventories, retained numeric level labels, continued dictionary search, deeper-base rejection, existing parser examples, and a real SQLite build. Browser/device verification remains pending. Check narrow screens, long Telugu forms, inactive/error states, and Refresh after a completed batch before deployment.
