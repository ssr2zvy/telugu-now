# Reader fixes — patch 05

## Brief audio bar on text-given pages

Page-owned visibility, response audio, recording range, errors and animation state were reset in a passive effect. This allowed stale presentation on navigation. The reset now runs in a layout effect before paint, keyed by profile, observation, phase, question mode and scroll setting. Only audio-given prompts initialize visible audio controls. A hidden, idle text-given prompt also suppresses the previous bar's opacity transition/exit animation. Explicit reveal, recording, playback, positions and gestures remain.

## Oversized words

At the preferred font size, the renderer measures each complete word against available reader width. Only oversized words allow manual hyphenation. Break opportunities are between Intl.Segmenter Telugu graphemes, never inside a conjunct, combining sequence or joiner sequence. They display a hyphen only at a chosen line break. CSS specifies the ASCII `-` glyph. The browser measures the visible hyphen as part of the line for width fitting, `text-wrap: balance` and centered alignment. Existing height fitting still applies. Normal words retain unbroken wrappers.

The display-only soft-hyphen spans are hidden from accessibility and omitted from source-offset traversal and native reader copying. Stored text, counts and parser inputs do not change. Wrapped-word hit testing checks individual graphemes but returns the original entire word. Highlight textures remain per grapheme.

The font-fit cache reapplies the same oversized-word decision on reuse and resize. Offscreen prewarming now populates actual text and the selected font, using matching word/break markup; previously it measured an empty element.

## Validation and deployment checks

Targeted renderer/segmentation/range/width-decision tests and TypeScript checks pass. The frontend production build passes. Browser/device validation is pending: Chromium was unavailable in this environment. Browser balancing and manual-hyphen rendering need checking in supported Safari/Chromium versions; CSS balancing may fall back to normal wrapping for long paragraphs.

Before deployment, navigate from an open audio prompt into a text prompt in tap and scroll modes, including back/forward and phase changes. Confirm no flash, then reveal/record/play normally. Test an oversized Telugu word with gradients on/off at narrow/mobile widths; check visible end-of-line hyphens, centered lines, copied original spelling, and taps on both halves opening the same whole word. Check resizing and cached next/previous observations.
