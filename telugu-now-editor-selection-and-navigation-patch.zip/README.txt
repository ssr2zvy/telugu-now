Telugu Now — editor selection and navigation patch

Base: main commit e7c9b9cb4e166548efb2aef72cdff195d3c58b0c
This is a new incremental patch AFTER the previously applied paste-and-move patch.

Apply ONE of these options from the repository root:
1. git apply --check /path/to/changes.patch
   git apply /path/to/changes.patch
2. Copy the contents of replacement-files/ onto the repository root.
Do not apply both options. Review conflicts if main has changed since the base.
No database migration, secret, dependency change, deployment or reset is required.

Changes
- One non-editable visible text surface; the native hardware-input bridge is hidden.
  Custom selection and caret geometry measure the visible shaped Telugu text itself,
  rather than a separately laid-out mirror. Native selection is no longer imported
  over the custom cursor after edits.
- Double tap/click enables selection and selects the touched word. Blank clicks
  clear selection mode without relocating the cursor. An empty file still opens
  the keyboard when tapped. Long press retains cursor/selection dragging and lens.
- Smaller selection, copy and paste icons; Copy is on the right, selection and
  Paste on the left. Selection icon has no dotted box. Control/Alt label: క్+త్+ల్.
- Keyboard-hide key is on its second row below Backspace, not in the file header.
- Appearance > File editor > Title size / Text size. Defaults: title 26px,
  body 20px. File white background and black left-aligned text remain.
- File header has no Back, X or persistent saved-status control. Swipe right to
  return to its containing directory, with the explorer revealed underneath.
- Unsaved swipe attempts snap back and show an icon-only live save confirmation.
  Cancel stays in the editor; the check allows return only once saved. Errors
  allow retry; revision conflicts retain the existing save-as-copy recovery.
- Unsaved for five seconds shows a dismissible Telugu error popup. Successful
  autosave clears it. Local recovery and serialized autosaves remain intact.
- Hardware arrow/Home/End and Ctrl/Cmd+A use the custom selection state.

Validation
- Full TypeScript, client and server production build passed.
- 36 focused unit/render tests passed.
- Mobile-sized Chromium checks passed for selection at second/third-line starts,
  non-overlapping highlight rows and repeated/rapid backspace across three Telugu
  fonts; double tap, blank clicks, keyboard placement, typography, clean swipe,
  delayed save warning and guarded swipe-back passed.
- Physical iPhone/iPad not tested. WebKit could not run because required host
  libraries were unavailable; do not interpret Chromium checks as iOS validation.

This ZIP changes source files only. It has not been pushed or deployed.
